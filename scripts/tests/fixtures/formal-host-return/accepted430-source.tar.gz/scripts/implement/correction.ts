import {
  verifyTestInterruption,
  verifyHostTestInterruption,
  interruptedTestOrigin,
} from './test-interruption.ts';
import { RecordObservation } from './record-observation.ts';
import { runtimeRecords, verifyReviewedRuntime, runtimeInstructions } from './runtime-records.ts';
import {
  authorTests,
  prepareTestBaseline,
  verifyTestArtifacts,
  readPreparedTestRecord,
} from './test-author.ts';
import type { TestIntake } from './test-author.ts';
import { testDiagnostics } from './test-diagnostics.ts';
import assert from 'node:assert/strict';
import {
  hostPreparationRecord,
  hostPreparationShape,
  readReference,
  hostReturnContext,
  verifyHostReturn,
} from './host-records.ts';
import { verifyReviewReturn, reviewReturnContext } from './review-recovery-records.ts';
import { checkRevision, revisionContext } from './revision.ts';
import { issueText } from './issue.ts';
import { parseRepairReply, repairInstructions } from './repair.ts';
import { parseReview, reviewInstructions, reviewSummary } from './review.ts';
import { preserveWalkthrough } from './walkthrough.ts';
import type { SavedWalkthrough } from './walkthrough.ts';
import type { Review } from './review.ts';
import { researchContext, verifyReportBase } from './research-handoff.ts';
import { assertConfig, assertProbeConfig, assertState, testRecordsShape } from './input.ts';
import { outside } from '../shared/values.ts';
import type {
  Config,
  ReviewConfig,
  ProbeConfig,
  State,
  ActorRole,
  StopReason,
  CaptureDecision,
} from './input.ts';
import { command, assertRunning, interruptionMessage } from '../shared/process.ts';
import { createHash } from 'node:crypto';
import { rmdirSync } from 'node:fs';
import {
  readFile,
  writeFile,
  mkdir,
  rename,
  lstat,
  readlink,
  rm,
  readdir,
  cp,
  realpath,
} from 'node:fs/promises';
import { resolve, dirname, relative } from 'node:path';

type Persist = () => Promise<void>;
type ModelResult = { stdout: string } | { stop: StopReason };
type RepairReference = {
  attempt: number;
  prefix: string;
  sourceBefore: string;
  sourceAfter: string;
  stdoutHash: string;
};
const digest = (value: string | Buffer) => createHash('sha256').update(value).digest('hex');

async function save(path: string, value: State) {
  await writeFile(`${path}.tmp`, JSON.stringify(value, null, 2));
  await rename(`${path}.tmp`, path);
}

// Plain documentation and saved verification records do not change the rendered app.
// Keep media, executable files and symlinks in the capture identity.
function isCaptureRecord(name: string, destination: string) {
  return (
    name.endsWith('.md') ||
    (name.startsWith(`${dirname(destination)}/`) &&
      !name.startsWith(`${destination}/`) &&
      /\.(json|txt|log|stdout|stderr|diff)$/.test(name))
  );
}

type SourceFile = [string, number, string];
type Addition = { path: string; mode: number; symlink: boolean; content: string };

async function sourceFiles(
  cwd: string,
  additions?: Addition[],
  testManifest?: Record<string, string>,
) {
  const untracked = new Map<string, number>();
  if (additions) {
    const list = await command(
      ['git', 'ls-files', '--others', '--exclude-standard', '-z'],
      cwd,
      '',
      10000,
    );
    assert(list.code === 0, 'Cannot record untracked files');
    for (const name of list.stdout.split('\0').filter(Boolean)) {
      untracked.set(name, untracked.size);
    }
  }
  const list = await command(
    ['git', 'ls-files', '-z', '--cached', ...(additions ? [] : ['--others', '--exclude-standard'])],
    cwd,
    '',
    10000,
  );
  if (list.code !== 0 || (testManifest && list.timedOut)) {
    throw Error('Cannot identify source files');
  }
  const entries: SourceFile[] = [];
  const names = new Set([
    ...list.stdout.split('\0').filter(Boolean),
    ...untracked.keys(),
    '.dotagents.json',
  ]);
  for (const name of [...names].sort()) {
    const file = await readSourceFile(cwd, name, untracked.has(name), testManifest);
    if (!file) {
      continue;
    }
    const { mode, symlink, bytes } = file;
    entries.push([name, mode, digest(bytes)]);
    const index = untracked.get(name);
    if (index !== undefined) {
      assert(additions);
      additions[index] = {
        path: name,
        mode,
        symlink,
        content: typeof bytes === 'string' ? bytes : bytes.toString('base64'),
      };
    }
  }
  return entries;
}

async function readSourceFile(
  cwd: string,
  name: string,
  required: boolean,
  testManifest?: Record<string, string>,
) {
  const path = resolve(cwd, name);
  const stat = await lstat(path).catch((error: unknown) => {
    if (!isMissing(error) || required) {
      throw error;
    }
    return undefined;
  });
  if (!stat) {
    // 削除済みのファイルはstage前後で同じ版として扱います。
    return undefined;
  }
  if (testManifest) {
    assert(stat.isFile() || stat.isSymbolicLink(), `テスト入力の種別が不正です: ${name}`);
  }
  // lstat後の消失は読取り失敗であり、確認済みの削除として扱いません。
  const symlink = stat.isSymbolicLink();
  const bytes = symlink ? await readlink(path) : await readFile(path);
  if (testManifest) {
    testManifest[name] = digest(Buffer.concat([Buffer.from(`${stat.mode}:`), Buffer.from(bytes)]));
  }
  return { mode: stat.mode, symlink, bytes };
}

function captureFiles(
  files: SourceFile[],
  cwd: string,
  destination: string,
  definitions: string[],
) {
  return files.filter(
    ([name, mode]) =>
      definitions.includes(resolve(cwd, name)) ||
      (mode & 0o170000) !== 0o100000 ||
      !!(mode & 0o111) ||
      !isCaptureRecord(name, destination),
  );
}

export async function snapshot(cwd: string, testManifest?: Record<string, string>) {
  return digest(JSON.stringify(await sourceFiles(cwd, undefined, testManifest)));
}

export async function recordArtifacts(cwd: string, baseCommit: string) {
  const additions: Addition[] = [];
  const files = await sourceFiles(cwd, additions);
  const diff = await command(
    [
      'git',
      '-c',
      'core.filemode=true',
      'diff',
      '--binary',
      '--full-index',
      '--no-ext-diff',
      '--no-textconv',
      '--no-renames',
      baseCommit,
    ],
    cwd,
    '',
    10000,
  );
  assert(diff.code === 0 && !diff.timedOut, 'Cannot preserve deliverable diff');
  const source = digest(JSON.stringify(files));
  assert(source === (await snapshot(cwd)), 'Source changed while preserving deliverables');
  return { source, files, additions, diff: diff.stdout };
}

async function validate(config: ReviewConfig) {
  if (!outside(resolve(config.cwd), resolve(config.runDir))) {
    throw Error('Evidence must be outside the worktree');
  }
  await mkdir(config.runDir, { recursive: true });
  if (!outside(await realpath(config.cwd), await realpath(config.runDir))) {
    throw Error('Evidence must not resolve inside the worktree');
  }
}

async function readIssue(config: ReviewConfig, record = false) {
  if (record) {
    const files = await readdir(config.runDir);
    assert(
      !files.some((name) => ['issue.stdout', 'issue.stderr', 'issue.txt'].includes(name)),
      'Initial Issue evidence already exists; preserve existing run and use a new run',
    );
  }
  const result = await command(
    config.issue,
    config.cwd,
    '',
    30000,
    record ? resolve(config.runDir, 'issue') : undefined,
  );

  if (result.code !== 0 || result.timedOut || !result.stdout.trim()) {
    throw Error('Issue unavailable');
  }
  return issueText(result.stdout);
}

// Use only the Issue just read at this boundary; checkRevision reads the remaining
// revision inputs afresh. Keep its failures ahead of the generic Issue hash check.
async function revisionUnchanged(config: ReviewConfig, issue: string) {
  if (config.targetText !== undefined) {
    if (config.revision) {
      assert(config.targetText === config.revision.targetText, '検証中に対象設定が変更されました');
    } else {
      assert(
        (await lstat(resolve(config.cwd, '.dotagents.json'))).isFile() &&
          (await readFile(resolve(config.cwd, '.dotagents.json'), 'utf8')) === config.targetText,
        '検証中に対象設定が変更されました',
      );
    }
  }
  if (config.revision) {
    await checkRevision(
      config.revision,
      config.cwd,
      async (argv, cwd) => {
        const result = await command(argv, cwd, '', 660000);
        assert(result.code === 0 && !result.timedOut, 'Revision target unavailable');
        return result.stdout.trim();
      },
      { issue },
    );
  }
}

async function readEntryIssue(config: ReviewConfig, record: boolean) {
  const issue = await readIssue(config, record);
  await revisionUnchanged(config, issue);
  if (record) {
    // Record the comparison text only after the revision target matched at entry.
    await writeFile(resolve(config.runDir, 'issue.txt'), issue, { flag: 'wx' });
  }
  return issue;
}

async function runModel(
  config: ReviewConfig,
  state: State,
  role: ActorRole,
  argv: string[],
  prompt: string,
  persist: Persist,
  timeoutMs: number | null = null,
): Promise<ModelResult> {
  state[role]++;
  const prefix = resolve(config.runDir, `${role}-${state[role]}`);
  state.active = { role, prefix };
  await persist(); // Reserve before launching. An interrupted reservation is never reset.
  await writeFile(`${prefix}.prompt`, prompt, { flag: 'wx' });
  const result = await command(argv, config.cwd, prompt, timeoutMs, prefix, {
    ...process.env,
    DOTAGENTS_ACTOR_PREFIX: prefix,
  });
  state.modelMs += result.ms;
  state.active = null;
  state.events.push({
    role,
    source: state.source,
    code: result.code,
    timedOut: result.timedOut,
    ms: result.ms,
    prefix,
  });
  // Keep the persisted reservation until the next command reservation or terminal save.
  // A failure before that save must never make this attempt runnable again.
  if (result.timedOut) {
    return { stop: 'review_timeout' };
  }
  if (result.code !== 0) {
    return { stop: `${role}_failed` };
  }
  return result;
}

async function hostCommand(
  config: ReviewConfig,
  state: State,
  role: 'capture' | 'check',
  argv: string[],
  persist: Persist,
  captureDecision?: CaptureDecision,
) {
  const attempt =
    role !== 'check'
      ? state.events.filter((event) => event.role === role).length + 1
      : state.checks;
  const prefix = resolve(config.runDir, `${role}-${attempt}`);
  state.active = { role, prefix };
  await persist();
  const result = await command(argv, config.cwd, '', config.checkTimeMs, prefix);
  state.active = null;
  state.events.push({
    role,
    captureDecision,
    source: state.source,
    code: result.code,
    timedOut: result.timedOut,
    ms: result.ms,
    prefix,
  });
  await persist();
  return { ...result, prefix };
}

async function installMedia(config: ReviewConfig, output: string) {
  const names = await readdir(output);
  for (const name of names) {
    if (
      !/\.(png|jpe?g|webp|mp4|webm)$/i.test(name) ||
      !(await lstat(resolve(output, name))).isFile()
    ) {
      throw Error(`Invalid capture output: ${name}`);
    }
  }
  if (!names.length) {
    throw Error('Capture succeeded without required media');
  }
  assert(config.captureDestination);
  const destination = resolve(config.cwd, config.captureDestination);
  const parent = dirname(destination);
  await mkdir(parent, { recursive: true });
  if ((await realpath(parent)) !== parent) {
    throw Error('Capture destination must not resolve through a symlink');
  }
  await rm(destination, { recursive: true, force: true });
  await cp(output, destination, { recursive: true });
}

function captureDefinitions(config: ReviewConfig) {
  const command = config.capture ?? [];
  const directories = command.flatMap((argument, index) =>
    argument === '--cwd'
      ? [command[index + 1] ?? '']
      : argument.startsWith('--cwd=')
        ? [argument.slice('--cwd='.length)]
        : [],
  );
  const bases = [
    config.cwd,
    ...directories.filter(Boolean).map((path) => resolve(config.cwd, path)),
  ];
  return command.flatMap((argument) => {
    const separator = argument.startsWith('-') ? argument.indexOf('=') : -1;
    const paths = separator > 0 ? [argument, argument.slice(separator + 1)] : [argument];
    return paths.filter(Boolean).flatMap((path) => bases.map((base) => resolve(base, path)));
  });
}

async function captureIdentity(config: ReviewConfig, source: string, files: SourceFile[]) {
  assert(config.captureDestination);
  const definitions = captureDefinitions(config);
  const ignored = await command(
    [
      'git',
      '--literal-pathspecs',
      'ls-files',
      '-z',
      '--others',
      '--ignored',
      '--exclude-standard',
      '--',
      config.captureDestination,
      ...definitions
        .filter((path) => !outside(config.cwd, path))
        .map((path) => relative(config.cwd, path) || '.'),
    ],
    config.cwd,
    '',
    10000,
  );
  assert(ignored.code === 0 && !ignored.timedOut, 'Cannot identify capture media or definitions');
  const ignoredPaths = ignored.stdout
    .split('\0')
    .filter(Boolean)
    .map((path) => resolve(config.cwd, path));
  assert(
    !ignoredPaths.some(
      (path) =>
        definitions.includes(path) &&
        !(
          config.targetText !== undefined &&
          path === resolve(config.cwd, '.dotagents.json') &&
          files.some(([name]) => name === '.dotagents.json')
        ),
    ),
    'Capture definitions must not be excluded from source identity by Git ignore rules',
  );
  const destination = resolve(config.cwd, config.captureDestination);
  assert(
    !ignoredPaths.some((path) => !outside(destination, path)),
    'Capture media must not be excluded from source identity by Git ignore rules',
  );
  return config.captureRequired
    ? source
    : digest(
        JSON.stringify(captureFiles(files, config.cwd, config.captureDestination, definitions)),
      );
}

async function captureDecision(
  config: ReviewConfig,
  source: string,
  files: SourceFile[],
  previousSource?: string,
): Promise<CaptureDecision> {
  if (!config.capture) {
    return {
      outcome: 'not_required',
      reason: 'captureは未設定です。Issueの媒体要件との一致が必要です',
    };
  }
  const current = await captureIdentity(config, source, files);
  if (previousSource !== undefined) {
    return {
      outcome: previousSource === current ? 'reused' : 'execute',
      reason:
        previousSource === current
          ? 'このrun内でcaptureの入力と媒体が一致しています'
          : 'captureの入力または媒体が変わりました',
      source: current,
      previousSource,
    };
  }
  const unnecessary =
    !config.captureRequired && (await onlyPlainMarkdown(config, captureDefinitions(config)));
  return {
    outcome: unnecessary ? 'not_required' : 'execute',
    reason: unnecessary
      ? '通常のMarkdownだけの変更で、画面に影響しない入力として設定されています'
      : 'このrun内に一致するcaptureがありません',
    source: current,
  };
}

function initialUntrackedPaths(config: ReviewConfig, definitions: string[], output: string) {
  const pinnedTarget =
    config.targetText !== undefined &&
    !definitions.includes(resolve(config.cwd, '.dotagents.json'));
  return new Map(
    output
      .split('\0')
      .filter((path) => path && !(pinnedTarget && path === '.dotagents.json'))
      .map((path) => [path, false]),
  );
}

async function onlyPlainMarkdown(config: ReviewConfig, definitions: string[]) {
  const cwd = config.cwd;
  const tracked = await command(
    ['git', '-c', 'core.filemode=true', 'diff', '--raw', '--no-renames', '-z', 'HEAD'],
    cwd,
    '',
    10000,
  );
  const untracked = await command(
    [
      'git',
      'ls-files',
      '--others',
      '--exclude-standard',
      ...(config.targetText !== undefined ? ['--exclude=!/.dotagents.json'] : []),
      '-z',
    ],
    cwd,
    '',
    10000,
  );
  if (tracked.code !== 0 || untracked.code !== 0) {
    return false;
  }
  const paths = initialUntrackedPaths(config, definitions, untracked.stdout);
  const records = tracked.stdout.split('\0');
  for (let index = 0; index < records.length - 1; index += 2) {
    const header = records[index] ?? '';
    const path = records[index + 1];
    // Both sides matter: deleting a symlink or removing an executable bit changes code too.
    if (!path || !/^:(?:000000|100644) (?:000000|100644) /.test(header)) {
      return false;
    }
    paths.set(path, header.startsWith(':100644 000000 '));
  }
  if (!paths.size) {
    return false;
  }
  for (const [path, deleted] of paths) {
    if (
      definitions.includes(resolve(cwd, path)) ||
      !(await plainMarkdownFile(cwd, path, deleted))
    ) {
      return false;
    }
  }
  return true;
}

async function plainMarkdownFile(cwd: string, path: string, deleted: boolean) {
  if (!path.endsWith('.md')) {
    return false;
  }
  try {
    const stat = await lstat(resolve(cwd, path));
    return stat.isFile() && !(stat.mode & 0o111);
  } catch (error) {
    return deleted && isMissing(error);
  }
}

async function verifyHost(
  config: ReviewConfig,
  state: State,
  persist: Persist,
  observedFiles?: SourceFile[],
): Promise<{ stop?: StopReason; findings?: string }> {
  const files = observedFiles ?? (await sourceFiles(config.cwd));
  state.source = digest(JSON.stringify(files));
  const decision = await captureDecision(config, state.source, files, state.captureSource);
  if (config.capture && decision.outcome === 'execute') {
    state.captureSource = undefined;
    const output = resolve(
      config.runDir,
      `capture-${state.events.filter((event) => event.role === 'capture').length + 1}-media`,
    );
    await mkdir(output); // Each capture has a fresh directory, never prior media.
    const capture = await hostCommand(
      config,
      state,
      'capture',
      [...config.capture, output],
      persist,
      decision,
    );
    const changed = await targetChange(config, state);
    if (changed) {
      return { stop: changed };
    }
    state.findings = `captureのログ: ${capture.prefix}.stdout と ${capture.prefix}.stderr。担当AIは既存権限内で環境の根拠を調査してください。ホスト環境の変更には許可が必要です。実行失敗は修正へ戻してください。`;
    if (capture.timedOut) {
      return { stop: 'capture_timeout' };
    }
    if (capture.code === null || capture.code === 78) {
      return { stop: 'capture_unavailable' };
    }
    if (capture.code !== 0) {
      return { findings: state.findings };
    }
    await installMedia(config, output);
    const installed = await sourceFiles(config.cwd);
    state.source = digest(JSON.stringify(installed));
    state.captureSource = await captureIdentity(config, state.source, installed);
    await persist();
  }
  return verifyCheck(config, state, persist, decision);
}

async function verifyCheck(
  config: ReviewConfig,
  state: State,
  persist: Persist,
  decision: CaptureDecision,
): Promise<{ stop?: StopReason; findings?: string }> {
  state.checks++;
  const checked = await hostCommand(config, state, 'check', config.check, persist, decision);
  const changed = await targetChange(config, state);
  if (changed) {
    return { stop: changed };
  }
  state.findings = `checkのログ: ${checked.prefix}.stdout と ${checked.prefix}.stderr。`;
  if (checked.timedOut || checked.code === null) {
    return { stop: 'check_unavailable' };
  }
  return checked.code === 0
    ? {}
    : {
        findings: `checkが失敗しました。${checked.prefix}.stdout と ${checked.prefix}.stderr を読んでください。`,
      };
}

async function reviewTarget(
  config: ReviewConfig,
  state: State,
  issue: string,
  repairsSinceReview: RepairReference[],
) {
  const prefix = resolve(config.runDir, `review-${state.review + 1}`);
  const additions: Addition[] = [];
  const files = await sourceFiles(config.cwd, additions);
  if (digest(JSON.stringify(files)) !== state.source) {
    return { stop: 'source_changed' as const };
  }
  const check = state.events.findLast((event) => event.role === 'check');
  assert(
    check && check.code === 0 && !check.timedOut && check.source === state.source,
    'Review requires successful check of current source',
  );
  for (const repair of repairsSinceReview) {
    try {
      assert(
        digest(await readFile(`${repair.prefix}.stdout`)) === repair.stdoutHash,
        'Repair response changed',
      );
    } catch (error) {
      state.findings = `Cannot hand off repair response at ${repair.prefix}.stdout: ${error instanceof Error ? error.message : String(error)}; preserve the run and investigate before further evaluation.`;
      return { stop: 'invalid_repair' as const };
    }
  }
  const target = {
    runtimeRecords: await runtimeRecords(config),
    issue: { hash: state.issueHash, content: issue },
    baseCommit: state.baseCommit,
    reports: config.reports ?? [],
    revision: config.revision,
    hostReturn: config.hostReturn,
    testInterruption: interruptedTestOrigin(config),
    reviewReturn: config.reviewReturn,
    hostPreparation: config.hostPreparation,
    source: state.source,
    latestRepair: repairsSinceReview.at(-1) ?? null,
    repairsSinceReview,
    tests: state.testRecords ?? [],
    files,
    check: {
      command: config.check,
      ...check,
      stdoutHash: digest(await readFile(`${check.prefix}.stdout`)),
      stderrHash: digest(await readFile(`${check.prefix}.stderr`)),
    },
    model: { command: config.review, settings: config.reviewModel ?? null },
    configHash: state.configHash,
  };
  const targetId = digest(JSON.stringify(target));
  await writeFile(`${prefix}.target.json`, JSON.stringify({ targetId, ...target }, null, 2), {
    flag: 'wx',
  });
  const diff = await command(
    [
      'git',
      '-c',
      'core.filemode=true',
      'diff',
      '--binary',
      '--full-index',
      '--no-ext-diff',
      '--no-textconv',
      '--no-renames',
      state.baseCommit,
    ],
    config.cwd,
    '',
    10000,
  );
  assert(diff.code === 0, 'Cannot record review diff');
  await writeFile(`${prefix}.diff`, diff.stdout, { flag: 'wx' });
  await writeFile(`${prefix}.additions.json`, JSON.stringify(additions, null, 2), { flag: 'wx' });
  return { prefix, targetId, files, runtimeRecords: target.runtimeRecords };
}

function documentVersions(review: Review, files: [string, number, string][]) {
  return review.documents.map((document) => {
    const file = files.find(([path]) => path === document.path);
    assert(file, `Document reference is not in reviewed source: ${document.path}`);
    // Symlinks can refer to ignored or external content not covered by the source identity.
    assert(
      (file[1] & 0o170000) === 0o100000,
      'Document reference must be a regular repository file',
    );
    return { ...document, mode: file[1], hash: file[2] };
  });
}

async function evaluate(
  config: ReviewConfig,
  state: State,
  issue: string,
  persist: Persist,
  repairsSinceReview: RepairReference[],
  timeoutMs: number | null = null,
): Promise<StopReason | null> {
  const target = await reviewTarget(config, state, issue, repairsSinceReview);
  if (target.stop) {
    return target.stop;
  }
  const history = state.reviewHistory;
  const prompt = [
    reviewInstructions,
    runtimeInstructions,
    revisionContext(config.revision),
    hostReturnContext(config.hostReturn),
    reviewReturnContext(config.reviewReturn),
    ...(config.hostPreparation
      ? [
          `復帰入口の照合後に許可された変更の版記録: ${JSON.stringify(config.hostPreparation)}。変更前・テスト転送後・初回実装後の版と差分を照合し、追加証拠の成立条件に影響する変更ならneeds_changesで必要な再検証へ戻してください。現在版へのホスト検証成功や受入の自動継承ではありません。`,
        ]
      : []),
    `ホストコンテキスト: ${JSON.stringify({ targetId: target.targetId, attempt: state.review + 1, targetRecord: `${target.prefix}.target.json`, diff: `${target.prefix}.diff`, additions: `${target.prefix}.additions.json`, previous: history.at(-1) ?? null })}`,
    `要求:\n${issue}`,
    researchContext(state.baseCommit, config.reports),
  ].join('\n');
  const before = await targetChange(config, state, target.runtimeRecords);
  if (before) {
    return before;
  }
  const reviewed = await runModel(
    config,
    state,
    'review',
    config.review,
    prompt,
    persist,
    timeoutMs,
  );
  if ('stop' in reviewed) {
    return reviewed.stop;
  }
  const changed = await targetChange(config, state);
  if (changed) {
    return changed;
  }
  let review: Review;
  let documents: ReturnType<typeof documentVersions>;
  let walkthrough: SavedWalkthrough | undefined;
  try {
    review = parseReview(reviewed.stdout, target.targetId, state.review, history.at(-1));
    documents = documentVersions(review, target.files);
    assert(state.source);
    walkthrough = await preserveWalkthrough(
      config.cwd,
      target.targetId,
      state.source,
      target.files,
      review.walkthrough,
    );
  } catch (error) {
    state.findings = `Invalid review: ${error instanceof Error ? error.message : String(error)}; raw response: ${target.prefix}.stdout`;
    return 'invalid_review';
  }
  try {
    await writeFile(
      `${target.prefix}.json`,
      JSON.stringify(
        { target: `${target.prefix}.target.json`, review, documents, walkthrough },
        null,
        2,
      ),
      { flag: 'wx' },
    );
  } catch (error) {
    state.findings = `Cannot save review at ${target.prefix}.json: ${error instanceof Error ? error.message : String(error)}; raw response: ${target.prefix}.stdout; previous complete reviews remain in reviewHistory.`;
    return 'review_storage_failed';
  }
  history.push(review);
  state.findings = summarizeReviews(state);
  return null;
}

function summarizeReviews(state: State) {
  return reviewSummary(
    state.reviewHistory,
    state.events.filter((event) => event.role === 'review').map((event) => `${event.prefix}.json`),
  );
}

async function requirementsChanged(config: ReviewConfig, state: State) {
  const currentIssue = await readIssue(config);
  await revisionUnchanged(config, currentIssue);
  return digest(currentIssue) !== state.issueHash;
}

async function repairOutcome(
  config: Config,
  state: State,
  stdout: string,
  repairsSinceReview: RepairReference[],
  observedFiles?: SourceFile[],
): Promise<StopReason | RepairReference[]> {
  const value = parseRepairReply(stdout);
  state.findings = value.findings;
  if (value.status === 'invalid') {
    return 'invalid_repair';
  }
  if (value.status === 'needs_host') {
    state.source = observedFiles
      ? digest(JSON.stringify(observedFiles))
      : await snapshot(config.cwd);
    return 'host_verification_required';
  }
  if (value.status === 'needs_human') {
    return 'human_decision_required';
  }
  assert(state.source);
  return [
    ...repairsSinceReview,
    {
      attempt: state.repair,
      prefix: resolve(config.runDir, `repair-${state.repair}`),
      sourceBefore: state.source,
      sourceAfter: observedFiles
        ? digest(JSON.stringify(observedFiles))
        : await snapshot(config.cwd),
      stdoutHash: digest(stdout),
    },
  ];
}

async function cycle(
  config: Config,
  state: State,
  issue: string,
  persist: Persist,
  repairsSinceReview: RepairReference[],
): Promise<StopReason | RepairReference[]> {
  if (await requirementsChanged(config, state)) {
    return 'requirements_changed';
  }
  const invalidTests = await testArtifactStop(config, state);
  if (invalidTests.stop) {
    return invalidTests.stop;
  }
  const host = await verifyHost(config, state, persist, invalidTests.files);
  if (host.stop) {
    return host.stop;
  }
  let findings = host.findings;
  if (findings && state.reviewHistory.length) {
    findings += `\n過去の独立評価（過去の記録です。現在の成果物を確認してください）:\n${summarizeReviews(state)}`;
  }
  if (!findings) {
    const stopped = await evaluate(config, state, issue, persist, repairsSinceReview);
    if (stopped) {
      return stopped;
    }
    if (state.reviewHistory.at(-1)?.status === 'accepted') {
      return 'ready_for_human_review';
    }
    findings = state.findings;
    // The completed review has consumed these explanations. Check failures do not.
    repairsSinceReview = [];
  }
  const testing = await testBeforeRepair(config, state, issue, persist);
  if (testing) {
    return testing;
  }
  return performRepair(config, state, issue, persist, repairsSinceReview, findings);
}

async function performRepair(
  config: Config,
  state: State,
  issue: string,
  persist: Persist,
  repairsSinceReview: RepairReference[],
  findings: string | undefined,
): Promise<StopReason | RepairReference[]> {
  const prompt = [
    `独立テストの記録: ${JSON.stringify(state.testRecords ?? [])}。対応する.jsonのfindingsと成果物を読んでください。修正前の狙った失敗と修正後の成功・正常動作を区別してください。`,
    ...(config.test && state.test
      ? [
          `テスト診断の振り分け記録: ${resolve(config.runDir, `test-${state.test}.routing.json`)}。対応不明・評価後の版変更によって診断から除外した必須指摘も通常修正で調べ、理由を残してください。保護対象への変更が必要なら別の独立テスト工程へ戻し、要求変更は人へ戻してください。`,
        ]
      : []),
    'これらの合意済み要求の範囲内だけで修正してください。現在のファイルを読み、根本原因を直してください。',
    '指摘が再発した場合は、既存の評価記録と過去の修正結果を現在の成果物と比較し、原因と修正方法を見直して、合意範囲内で必要な修正を続けてください。同じ前提の下で修正が効かず原因仮説を見直す必要がある場合は、repairInstructionsで渡す共通手順に従い、複数の修正に共通する前提と否定・支持の観測を明示してください。失敗回数だけで前提を誤りと断定せず、結果を区別できる確認から次の修正を選んでください。新しい根拠が得られなければ未確認事項と次に必要な調査・判断を残してください。範囲外の改善や好みを完了条件にしないでください。',
    revisionContext(config.revision),
    hostReturnContext(config.hostReturn),
    reviewReturnContext(config.reviewReturn),
    '文書内容の欠陥は修正へ戻し、影響するcheckと独立評価を更新してください。',
    '合意済みの受入基準と必要な振る舞いの検証を保ち、checkを通すために現実的な退行を隠さないでください。',
    '修正の診断や妥当性の確認に必要な範囲のcheckだけを実行してください。',
    repairInstructions(
      config.capture && config.captureDestination
        ? { destination: config.captureDestination }
        : null,
    ),
    `対象のcheck/capture契約（弱めたり置き換えたりしないでください）: ${JSON.stringify({ check: config.check, capture: config.capture ? { command: config.capture, destination: config.captureDestination, required: config.captureRequired } : null })}`,
    `要求:\n${issue}\n失敗の根拠:\n${findings}`,
    researchContext(state.baseCommit, config.reports),
  ].join('\n');
  if (await requirementsChanged(config, state)) {
    return 'requirements_changed';
  }
  const repaired = await runModel(config, state, 'repair', config.repair, prompt, persist);
  if ('stop' in repaired) {
    return repaired.stop;
  }
  const changedTests = await testArtifactStop(config, state);
  if (changedTests.stop) {
    return changedTests.stop;
  }
  return repairOutcome(config, state, repaired.stdout, repairsSinceReview, changedTests.files);
}

async function targetChange(
  config: ReviewConfig,
  state: State,
  currentRuntime: unknown[] = [],
): Promise<StopReason | null> {
  const issue = await readIssue(config);
  await revisionUnchanged(config, issue);
  if (digest(issue) !== state.issueHash) {
    return 'requirements_changed';
  }
  const manifest: Record<string, string> | undefined = state.testRecords?.length ? {} : undefined;
  if ((await snapshot(config.cwd, manifest)) !== state.source) {
    return 'source_changed';
  }
  const observation = new RecordObservation();
  try {
    await verifyReviewedRuntime(state, observation, currentRuntime);
  } catch (error) {
    state.findings = String(error);
    return 'host_evidence_changed';
  }
  if (
    config.hostReturn ||
    config.reviewReturn ||
    config.testInterruption ||
    'preparedTests' in config
  ) {
    try {
      await verifyHostEntry(config, state, undefined, observation);
    } catch (error) {
      state.findings = error instanceof Error ? error.message : String(error);
      return 'host_evidence_changed';
    }
  }
  return manifest
    ? ((await testArtifactStop(config, state, { manifest, records: observation })).stop ?? null)
    : null;
}

// 保全確認と直後の版識別だけで共有し、次の工程へは持ち越しません。
async function testArtifactStop(
  config: ReviewConfig,
  state: State,
  intake?: TestIntake,
): Promise<{ stop?: StopReason; files?: SourceFile[] }> {
  try {
    const records = state.testRecords ?? [];
    const manifest: Record<string, string> = intake?.manifest ?? {};
    const files =
      !intake && records.some((record) => Object.keys(record.files).length > 0)
        ? await sourceFiles(config.cwd, undefined, manifest)
        : undefined;
    await verifyTestArtifacts(config.cwd, records, manifest, intake?.records);
    return { files };
  } catch (error) {
    state.findings = error instanceof Error ? error.message : String(error);
    return { stop: 'invalid_test' };
  }
}

async function testCheckEvidence(config: Config, state: State) {
  const check = state.events.findLast((event) => event.role === 'check');
  if (!check) {
    return [];
  }
  return [
    {
      command: config.check,
      source: check.source ?? '',
      code: check.code,
      stdout: await readFile(`${check.prefix}.stdout`, 'utf8'),
      stderr: await readFile(`${check.prefix}.stderr`, 'utf8'),
    },
  ];
}

async function testBeforeRepair(
  config: Config,
  state: State,
  issue: string,
  persist: Persist,
): Promise<StopReason | null> {
  if (!config.test) {
    return null;
  }
  assert(config.testBaseline);
  state.test = (state.test ?? 0) + 1;
  const prefix = resolve(config.runDir, `test-${state.test}`);
  state.active = { role: 'test', prefix };
  await persist();
  try {
    const evidence = await testCheckEvidence(config, state);
    let observedManifest: Record<string, string> | undefined;
    const diagnostics = await testDiagnostics(
      state,
      async () => {
        // 診断照合とテスト開始は同じ準備境界の観測を共有します。
        observedManifest = {};
        return sourceFiles(config.cwd, undefined, observedManifest);
      },
      prefix,
    );
    const tests = await authorTests({
      cwd: config.cwd,
      baseline: config.testBaseline,
      prefix,
      issue,
      stage: 'correction',
      baseCommit: state.baseCommit,
      revisionRequest: config.revision?.request,
      check: config.check,
      setup: config.setup,
      reports: config.reports,
      actor: config.test,
      previous: state.testRecords ?? [],
      evidence,
      diagnostics,
      observedManifest,
      completed: async (result) => {
        state.active = null;
        state.modelMs += result.ms;
        state.events.push({
          role: 'test',
          prefix,
          source: state.source,
          code: result.code,
          timedOut: result.timedOut,
          ms: result.ms,
        });
        await persist();
      },
    });
    state.findings = tests.reply.findings;
    if (tests.reply.status === 'needs_human') {
      return 'human_decision_required';
    }
    if (tests.reply.status === 'needs_host') {
      state.source = await snapshot(config.cwd);
      return 'host_verification_required';
    }
    assert(tests.record);
    state.testRecords = [...(state.testRecords ?? []), tests.record];
    state.source = await snapshot(config.cwd);
    await persist();
    return null;
  } catch (error) {
    assertRunning();
    state.findings = `${prefix}: ${error instanceof Error ? error.message : String(error)}`;
    return error instanceof Error && error.cause === 'test_failed' ? 'test_failed' : 'invalid_test';
  }
}

type Verification = (state: State, issue: string, persist: Persist) => Promise<StopReason>;

export async function run(config: unknown, publicationHead?: string) {
  assertConfig(config);
  return lockedRun(
    config,
    async (state, issue, persist) => {
      // 今回完了した修正だけを次の評価へ渡し、別runの説明を混ぜない。
      let result: StopReason | RepairReference[] = [];
      while (typeof result !== 'string') {
        result = await cycle(config, state, issue, persist, result);
      }
      return result;
    },
    publicationHead,
  );
}

export async function reviewOnce(config: unknown) {
  assertProbeConfig(config);
  return lockedRun(config, async (state, issue, persist) => {
    const host = await verifyHost(config, state, persist);
    if (host.stop) {
      return host.stop;
    }
    if (host.findings) {
      return 'check_failed';
    }
    return (
      (await evaluate(config, state, issue, persist, [], config.reviewTimeMs)) ?? 'review_completed'
    );
  });
}

async function lockedRun(
  config: Config | ProbeConfig,
  verify: Verification,
  publicationHead?: string,
) {
  await validate(config);
  const lock = resolve(config.runDir, 'lock');
  await mkdir(lock); // 既存lockは照合が必要であり、自動で引き継がない。
  const path = resolve(config.runDir, 'state.json');
  let current: State | undefined;
  let state: State | undefined;
  let failure: { error: unknown } | undefined;
  try {
    state = await execute(
      config,
      (...args) => {
        current = args[0]; // 既存の終端読取り・開始拒否では原記録を更新しない。
        return verify(...args);
      },
      publicationHead,
    );
    assertRunning();
  } catch (error) {
    failure = { error: await interruptionError(path, current, error) };
  }
  if (failure?.error instanceof InterruptionStorageError) {
    throw failure.error; // 未確定の終端を他の実行が採用しないよう、lockも保全する。
  }
  try {
    // 最後の非同期保存まで排他を保つ。同期削除と返却の間には待機を置かない。
    rmdirSync(lock);
  } catch (error) {
    const releaseError = await interruptionError(path, current, error);
    // 解放失敗時はlockを残し、先行する障害も失わない。
    throw failure ? combinedFailure(failure.error, releaseError) : releaseError;
  }
  if (failure) {
    throw failure.error;
  }
  assert(state);
  return state;
}

function observedInterruption() {
  try {
    assertRunning();
    return false;
  } catch {
    return true;
  }
}

class InterruptionStorageError extends AggregateError {}

function combinedFailure(
  first: unknown,
  second: unknown,
  ErrorType: new (errors: unknown[], message: string) => AggregateError = AggregateError,
) {
  const message = (error: unknown) => (error instanceof Error ? error.message : String(error));
  return new ErrorType([first, second], `${message(first)}; ${message(second)}`);
}

async function interruptionError(path: string, state: State | undefined, error: unknown) {
  if (!state || state.result === 'interrupted' || !observedInterruption()) {
    return error;
  }
  state.result = 'interrupted';
  try {
    await saveTerminal(path, state);
  } catch (storageError) {
    return combinedFailure(error, storageError, InterruptionStorageError);
  }
  return error;
}

function isMissing(error: unknown): boolean {
  return error instanceof Error && 'code' in error && error.code === 'ENOENT';
}

function preparedTestReferences(config: ReviewConfig) {
  return 'preparedTests' in config && config.preparedTests !== undefined
    ? hostPreparationShape.array().min(1).parse(config.preparedTests)
    : [];
}

async function readProbeTests(config: ReviewConfig, issue: string, observation: RecordObservation) {
  const references = preparedTestReferences(config);
  if (references.length === 0) {
    return undefined;
  }
  const manifest: Record<string, string> = {};
  const cwd = await realpath(config.cwd);
  await snapshot(cwd, manifest);
  const intake = { manifest, records: observation };
  return Promise.all(
    references.map(async (ref) =>
      readPreparedTestRecord(await readReference(ref, observation), issue, cwd, intake),
    ),
  );
}

async function verifyProbeReferences(config: ReviewConfig, observation: RecordObservation) {
  const references = preparedTestReferences(config);
  if (references.length === 0) {
    return;
  }
  const cwd = await realpath(config.cwd);
  observation.retain(references.map((ref) => ref.path));
  for (const ref of references) {
    assert(outside(cwd, await realpath(ref.path)), '準備済みテスト記録はcheckoutの外に置きます');
    await readReference(ref, observation);
  }
}

async function initialTestRecords(
  config: Config | ProbeConfig,
  state: State,
  issue: string,
  observation: RecordObservation,
) {
  const prepared = await readProbeTests(config, issue, observation);
  if (prepared) {
    if (state.testRecords) {
      assert.deepStrictEqual(state.testRecords, prepared);
    }
    state.testRecords = prepared;
    return;
  }
  if (!state.testRecords && 'test' in config && config.test) {
    assert(config.testBaseline);
    try {
      const initial: unknown = JSON.parse(
        await readFile(resolve(dirname(config.runDir), 'test-records.json'), 'utf8'),
      );
      state.testRecords = testRecordsShape.parse(initial);
    } catch (error) {
      if (!isMissing(error)) {
        throw error;
      }
      await prepareTestBaseline(config.cwd, config.testBaseline);
      state.testRecords = [];
    }
  }
}

async function verifyHostEntry(
  config: ReviewConfig,
  state: State | undefined,
  publicationHead?: string,
  observation = new RecordObservation(),
) {
  await verifyProbeReferences(config, observation);
  if (config.testInterruption) {
    await verifyTestInterruption(config.testInterruption, dirname(config.runDir));
  }
  if (config.reviewReturn) {
    if (publicationHead) {
      // 成果物とmanifestは、このexecuteのstoppedStateで最後に一度観測する。
      assert(state?.result === 'ready_for_human_review', '公開commitには有効な終端検証が必要です');
      const parent = await command(
        ['git', 'rev-parse', `${publicationHead}^`],
        config.cwd,
        '',
        10000,
      );
      assert(
        parent.code === 0 && !parent.timedOut && parent.stdout.trim() === config.reviewReturn.head,
        '公開commitの親が停止時HEADと一致しません',
      );
      const changes = await command(
        ['git', 'status', '--porcelain', '--', '.', ':(top,exclude).dotagents.json'],
        config.cwd,
        '',
        10000,
      );
      assert(
        changes.code === 0 && !changes.timedOut && changes.stdout.trim() === '',
        '公開commitと検証済み成果物が一致しません',
      );
    }
    await verifyReviewReturn(
      config.reviewReturn,
      config.cwd,
      config.runDir,
      publicationHead,
      undefined,
      observation,
    );
    assert(
      state || config.reviewReturn.source === (await snapshot(config.cwd)),
      '復帰成果物が変わりました',
    );
  }
  if (config.hostReturn) {
    if (config.hostReturn.reviewReturn) {
      await verifyReviewReturn(
        config.hostReturn.reviewReturn,
        config.cwd,
        config.runDir,
        publicationHead,
        undefined,
        observation,
      );
    }
    const evidence = await verifyHostReturn(config.hostReturn, config.cwd, observation);
    await verifyHostTestInterruption(
      config.hostReturn,
      config.cwd,
      dirname(config.runDir),
      evidence,
    );
    const preparation = config.hostPreparation
      ? hostPreparationRecord.parse(JSON.parse(await readReference(config.hostPreparation)))
      : undefined;
    assert(
      !preparation || preparation.sourceBefore === evidence.source,
      'Host preparation does not match evidence source',
    );
    assert(
      state || (preparation?.sourceAfter ?? evidence.source) === (await snapshot(config.cwd)),
      'Host evidence does not match current deliverables',
    );
  }
}

// 終端結果の参照も新しい境界。旧stateは変更せず、公開前の再利用も照合する。
async function stoppedState(
  config: ReviewConfig,
  state: State,
  issue: string,
  observation: RecordObservation,
): Promise<State> {
  const manifest: Record<string, string> | undefined = state.testRecords?.length ? {} : undefined;
  const unchanged =
    state.issueHash === digest(issue) && state.source === (await snapshot(config.cwd, manifest));
  if (unchanged) {
    await verifyTestArtifacts(config.cwd, state.testRecords ?? [], manifest, observation);
  }
  return { ...state, result: unchanged ? state.result : 'target_changed_after_stop' };
}

async function execute(
  config: Config | ProbeConfig,
  verify: Verification,
  publicationHead?: string,
): Promise<State> {
  const path = resolve(config.runDir, 'state.json');
  let state: State | undefined;
  try {
    const value: unknown = JSON.parse(await readFile(path, 'utf8'));
    assertState(value);
    state = value;
  } catch (error) {
    if (!isMissing(error)) {
      throw error;
    }
  }
  const configHash = digest(JSON.stringify(config));
  if (state && state.configHash !== configHash) {
    throw Error('Run configuration changed; preserve the existing run');
  }
  if (state?.active) {
    throw Error(interruptionMessage);
  }
  const issue = await readEntryIssue(config, !state);
  const base =
    state?.baseCommit ??
    config.baseCommit ??
    (await command(['git', 'rev-parse', 'HEAD'], config.cwd, '', 10000)).stdout.trim();
  assert(/^[a-f0-9]{40,64}$/.test(base), 'Review requires a base commit');
  const git = async (...args: string[]) => {
    const result = await command(['git', ...args], config.cwd, '', 10000);
    assert(result.code === 0 && !result.timedOut, 'Cannot verify report base');
    return result.stdout.trim();
  };
  await verifyReportBase(base, config.reports ?? [], git);
  const observation = new RecordObservation();
  await verifyHostEntry(config, state, publicationHead, observation);
  if (state) {
    await verifyReviewedRuntime(state, observation);
  }
  if (state?.result) {
    return stoppedState(config, state, issue, observation);
  }
  state ??= {
    reviewFormat: 4,
    issueFormat: 1,
    baseCommit: base,
    reviewHistory: [],
    configHash,
    issueHash: digest(issue),
    repair: 0,
    review: 0,
    checks: 0,
    modelMs: 0,
    active: null,
    events: [],
  };
  await initialTestRecords(config, state, issue, observation);
  const persist = () => save(path, state);
  await persist();
  await finishVerification(path, state, issue, persist, verify);
  return state;
}

async function finishVerification(
  path: string,
  state: State,
  issue: string,
  persist: Persist,
  verify: Verification,
) {
  try {
    state.result = await verify(state, issue, persist);
    assertRunning();
    await saveTerminal(path, state);
    assertRunning();
  } catch (error) {
    throw await interruptionError(path, state, error);
  }
}

async function saveTerminal(path: string, state: State) {
  try {
    await save(path, state);
  } catch (error) {
    throw new Error(
      `${state.result}: ${state.findings ?? ''}; cannot save terminal state at ${path}: ${error instanceof Error ? error.message : String(error)}. Preserve the previous state and active reservation; do not resume this run.`,
      { cause: error },
    );
  }
}

if (import.meta.main) {
  console.error(
    '単独の修正CLIは廃止しました。通常開発はdevelopment.ts、評価試行はreview-probe.tsを使ってください。旧runは再開せず保全してください。',
  );
  process.exitCode = 1;
}
