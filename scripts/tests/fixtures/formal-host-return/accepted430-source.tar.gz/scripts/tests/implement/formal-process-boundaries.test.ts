import { test } from 'bun:test';
import assert from 'node:assert/strict';
import { z } from 'zod';
import { verifyInterruptedProcesses } from '../../implement/interrupted-processes.ts';

// #430では#428の初回中断祖先も照合する。lstart付きの通常復帰とは別の
// PID・親PID・command入口で、正規の親ホストだけを除外する必要がある。
// ホスト提示の呼出形を使い、修正前baselineにもテスト自体を読み込ませる。
const verify = z
  .custom<(stdout: string, input: Record<string, unknown>) => Promise<void>>(
    (value) => typeof value === 'function',
  )
  .parse(verifyInterruptedProcesses);

for (const entry of ['--test-interrupted-run', '--host-run']) {
  for (const form of [
    'equals',
    'separated',
    'quoted',
    'other-entry',
    'other-directory',
    'other-repo',
    'old-suffix',
    'new-suffix',
  ]) {
    test(`初回中断祖先の親ホスト除外はオプション全体を照合する: ${entry} ${form}`, async () => {
      const previousRun = '/fixture/initial-run';
      const ownerRun = entry === '--host-run' ? '/fixture/formal-run' : previousRun;
      const runDirectory = '/fixture/next-run';
      const cwd = '/fixture/checkout';
      const oldOption = form === 'other-entry' ? `--other${entry}` : entry;
      const directoryOption = form === 'other-directory' ? '--other--run-dir' : '--run-dir';
      const repoOption = form === 'other-repo' ? '--other--repo' : '--repo';
      const oldPath = form === 'old-suffix' ? `${ownerRun}/child` : ownerRun;
      const newPath = form === 'new-suffix' ? `${runDirectory}/child` : runDirectory;
      const pairs = [
        [oldOption, oldPath],
        [directoryOption, newPath],
        [repoOption, cwd],
      ];
      const args = pairs
        .map(([option, path]) =>
          form === 'quoted'
            ? `${option}="${path}"`
            : form === 'separated'
              ? `${option} ${path}`
              : `${option}=${path}`,
        )
        .join(' ');
      // 実際の親PIDを使うが、観測内容は固定する。プロセスを起動・killしない。
      const stdout = `${process.ppid} 0 bun /fixture/development.ts 99 ${args}`;
      const result = verify(stdout, {
        entry: '--test-interrupted-run',
        previousRun,
        runDirectory,
        review: ['/fixture/reviewer'],
        host: { cwd, issue: '99', repository: 'fixture/repo', common: '/fixture/git' },
        owner: { entry, previousRun: ownerRun, cwd, common: '/fixture/git' },
      });
      if (['equals', 'separated', 'quoted'].includes(form)) {
        await assert.doesNotReject(result);
      } else {
        await assert.rejects(result, /旧テストまたはホスト停止runの稼働プロセス.*PID=/);
      }
    });
  }
}
