import assert from 'node:assert/strict';
import { lstat, readFile, readdir, readlink, realpath, mkdir } from 'node:fs/promises';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { z } from 'zod';
import { hash } from './record-observation.ts';
import { verifyTestBaseline, testReplySchema, testInputFiles } from './test-author.ts';
import { verifyRuntimeActor } from './runtime-records.ts';
import { observeInterruption } from './interrupted-records.ts';
import { command } from '../shared/process.ts';
import { issueText } from './issue.ts';
import { researchContext } from './research-handoff.ts';
import { isRecord, outside } from '../shared/values.ts';
import type { readTarget } from '../shared/target.ts';
import type { HostReturn, verifyHostReturn } from './host-records.ts';
import type { InitialTestOwner } from './interrupted-processes.ts';

import type { TestInterruption } from './test-interruption-schema.ts';

async function recordText(path: string) {
  assert((await lstat(path)).isFile(), `原記録が通常ファイルではありません: ${path}`);
  return readFile(path, 'utf8');
}

async function tree(path: string): Promise<unknown> {
  const info = await lstat(path);
  if (info.isSymbolicLink()) {
    return [info.mode, await readlink(path)];
  }
  if (info.isFile()) {
    return [info.mode, hash(await readFile(path))];
  }
  assert(info.isDirectory(), `原記録の種別を照合できません: ${path}`);
  const entries = [];
  for (const name of (await readdir(path)).sort()) {
    // symlinkとworktreeの.git参照は内容だけを読み、run外の保存領域へ辿らない。
    entries.push([name, await tree(join(path, name))]);
  }
  return [info.mode, entries];
}

async function checked(argv: string[], cwd: string) {
  const result = await command(argv, cwd, '', 10000);
  assert(result.code === 0 && !result.timedOut, `照合コマンドに失敗しました: ${argv.join(' ')}`);
  return result.stdout.trim();
}

async function noLocks(path: string, inspected?: string) {
  for (const entry of await readdir(path, { withFileTypes: true })) {
    assert(
      !entry.name.endsWith('.lock') && entry.name !== 'lock',
      `lockが残っています: ${join(path, entry.name)}`,
    );
    const child = join(path, entry.name);
    if (entry.isDirectory() && child !== inspected) {
      await noLocks(child, inspected);
    }
  }
}

async function retained(input: Pick<TestInterruption, 'previousRun' | 'config'>) {
  const names = await readdir(input.previousRun);
  assert(
    !names.some((name) => name === 'lock' || name.endsWith('.lock')),
    '旧runにlockが残っています',
  );
  for (const workspace of ['test-baseline', 'test-1-workspace']) {
    await noLocks(join(input.previousRun, workspace, '.git'));
  }
  const git = await checked(['git', 'rev-parse', '--absolute-git-dir'], input.config.cwd);
  const common = await checked(
    ['git', 'rev-parse', '--path-format=absolute', '--git-common-dir'],
    input.config.cwd,
  );
  await noLocks(git);
  if (common !== git) {
    await noLocks(common, git);
  }
  const target = z.object({ remote: z.string() }).parse(JSON.parse(input.config.targetText));
  return {
    hash: hash(JSON.stringify(await tree(input.previousRun))),
    common: await realpath(common),
    remoteUrl: await checked(['git', 'remote', 'get-url', target.remote], input.config.cwd),
  };
}

export async function verifyTestInterruption(
  input: TestInterruption,
  runDirectory: string,
  directory = input.observations,
  owner?: InitialTestOwner,
) {
  await verifyObservedTestInterruption(
    input,
    runDirectory,
    directory,
    await retained(input),
    owner,
  );
}

async function verifyObservedTestInterruption(
  input: TestInterruption,
  runDirectory: string,
  directory: string,
  preserved: Awaited<ReturnType<typeof retained>>,
  owner?: InitialTestOwner,
) {
  const location = await realpath(directory);
  assert(
    outside(input.previousRun, location) && outside(input.config.cwd, location),
    '観測ログは旧run・旧checkoutの外に保存してください',
  );
  assert(
    (await checked(
      ['git', 'rev-parse', 'HEAD', '--symbolic-full-name', 'HEAD'],
      input.config.cwd,
    )) === `${input.head}\nrefs/heads/${input.branch}`,
    '旧checkoutのHEAD・branchが変更されました',
  );
  assert(preserved.remoteUrl === input.remoteUrl, '旧checkoutのremote設定が変更されました');
  assert(preserved.hash === input.retained, '旧runの原記録・応答・内容・モードが変更されました');
  const savedTarget = z
    .object({ cwd: z.string(), config: z.object({ repository: z.string() }) })
    .parse(JSON.parse(await recordText(join(input.previousRun, 'target.json'))));
  assert(
    savedTarget.cwd === input.host.cwd &&
      isAbsolute(input.host.cwd) &&
      (await realpath(input.host.cwd)) === input.host.cwd &&
      input.branch === `codex/development-${input.host.issue}` &&
      (await realpath(
        await checked(
          ['git', 'rev-parse', '--path-format=absolute', '--git-common-dir'],
          input.host.cwd,
        ),
      )) === preserved.common,
    '元ホストの対象root・Issue・Git領域が旧記録と一致しません',
  );
  await observeInterruption(
    {
      previousRun: input.previousRun,
      branch: input.branch,
      owner,
      host: {
        ...input.host,
        common: preserved.common,
        repository: savedTarget.config.repository,
      },
    },
    {
      ...input.config,
      issue: [],
      check: [],
      repair: [],
      runDir: join(runDirectory, 'verification'),
      checkTimeMs: 10000,
    },
    directory,
    runDirectory,
    '--test-interrupted-run',
  );
}

export function interruptedTestOrigin(config: {
  testInterruption?: TestInterruption;
  hostReturn?: HostReturn;
}) {
  return config.testInterruption ?? config.hostReturn?.testInterruption?.record;
}

export async function verifyHostTestInterruption(
  host: HostReturn,
  cwd: string,
  runDirectory: string,
  verified: Awaited<ReturnType<typeof verifyHostReturn>>,
) {
  const origin = host.testInterruption;
  if (!origin) {
    return;
  }
  const previous = verified.history.find((entry) => entry.previousRun === host.previousRun);
  const content = previous?.records.get(join(host.previousRun, 'verification-config.json'));
  assert(content, '初回テスト中断からのホスト停止設定がありません');
  const config: unknown = JSON.parse(content);
  assert(
    isRecord(config) &&
      config.cwd === cwd &&
      config.hostReturn === undefined &&
      config.reviewReturn === undefined &&
      config.revision === undefined &&
      JSON.stringify(config.testInterruption) === JSON.stringify(origin.record),
    '初回テスト中断の祖先・固定設定がホスト停止記録と一致しません',
  );
  const directory = await realpath(origin.observations);
  assert(
    outside(host.previousRun, directory) && outside(cwd, directory),
    '新しい中断観測はホスト停止run・checkoutの外に保存してください',
  );
  assert((await realpath(cwd)) === cwd, 'ホスト停止checkoutのcanonical rootが一致しません');
  const common = await realpath(
    await checked(['git', 'rev-parse', '--path-format=absolute', '--git-common-dir'], cwd),
  );
  await verifyTestInterruption(origin.record, runDirectory, directory, {
    entry: '--host-run',
    previousRun: host.previousRun,
    cwd,
    common,
  });
}

function eligible(names: string[]) {
  const allowed =
    /^(?:checkout|test-baseline(?:\.json)?|test-1(?:-workspace(?:\.json)?|\.target\.json|\.prompt|\.stdout|\.stderr)|test-codex-[\w-]+|issue\.(?:json|stdout)|target\.json|setup-\d+\.(?:stdout|stderr))$/;
  for (const name of names) {
    assert(allowed.test(name), `初回テスト中断の対象外の履歴・保存結果です: ${name}`);
  }
}

async function actorResponse(dir: string, names: string[], targetId: string) {
  const actors = names.filter((name) => name.startsWith('test-codex-'));
  assert(actors.length === 1, '付属actor原記録を一意に照合できません');
  const name = actors[0];
  assert(name, 'actor原記録がありません');
  const actor = join(dir, name);
  assert(
    (await lstat(actor)).isDirectory() && (await realpath(actor)) === actor,
    'actor原記録の場所を照合できません',
  );
  const path = join(actor, 'actor.json');
  // host stdout未保存でもactorの呼出しは原記録へ直接照合する。
  const raw: unknown = JSON.parse(await recordText(path));
  verifyRuntimeActor(raw, 'test', name);
  assert(
    isRecord(raw) && raw.hostPrefix === 'test-1' && raw.ignoreUserConfig === true,
    'actorの呼出し・prefix・runtime対応を照合できません',
  );
  assert(
    JSON.stringify(JSON.parse(await recordText(join(actor, 'schema.json')))) ===
      JSON.stringify(testReplySchema),
    'actor応答schemaが一致しません',
  );
  const final = await recordText(join(actor, 'final.json'));
  const reply: unknown = JSON.parse(final);
  assert(
    isRecord(reply) && reply.targetId === targetId,
    'actor原応答と入力manifestの対応が不一致です',
  );
  const events = (await recordText(join(actor, 'events.jsonl')))
    .trim()
    .split('\n')
    .map((line) => JSON.parse(line) as unknown);
  assert(
    !events.some(
      (event) => isRecord(event) && ['error', 'turn.failed'].includes(String(event.type)),
    ),
    'actor実行失敗の原記録があります',
  );
  const replies = events.filter(
    (event) =>
      isRecord(event) &&
      event.type === 'item.completed' &&
      isRecord(event.item) &&
      event.item.type === 'agent_message',
  );
  const last = replies.at(-1);
  assert(
    isRecord(last) && isRecord(last.item) && last.item.text === final,
    'actor原応答とeventsの応答が不一致です',
  );
  assert(
    events.some((event) => isRecord(event) && event.type === 'turn.completed'),
    'actor応答の終了を照合できません',
  );
  await recordText(join(actor, 'stderr.log'));
  if (names.includes('test-1.stdout')) {
    const stdout = await recordText(join(dir, 'test-1.stdout'));
    assert(stdout === final || stdout === `${final}\n`, 'ホスト応答とactor原応答が不一致です');
  }
}

export async function previousTestInterruption(input: {
  issue: string;
  directory?: string;
  runDirectory?: string;
  cwd: string;
  original: string;
  head: string;
  branch: string;
  target: Awaited<ReturnType<typeof readTarget>>;
  localOnly: boolean;
}) {
  if (!input.directory) {
    return undefined;
  }
  assert(
    input.runDirectory && input.localOnly,
    '初回テスト中断復帰は新しい--run-dirと--no-publishが必要です',
  );
  const dir = await realpath(input.directory);
  assert(
    dirname(resolve(input.runDirectory)) === dirname(dir) &&
      outside(dir, resolve(input.runDirectory)),
    '復帰先は旧runと同じ親の新しい保存先にしてください',
  );
  assert(input.cwd === join(dir, 'checkout'), '旧checkoutが一致しません');
  const entries = await readdir(dir, { withFileTypes: true });
  const names = entries.map((entry) => entry.name);
  eligible(names);
  for (const name of ['checkout', 'test-baseline', 'test-1-workspace']) {
    const path = join(dir, name);
    assert(
      (await lstat(path)).isDirectory() && (await realpath(path)) === path,
      '旧checkout・baseline・workspaceの対応を照合できません',
    );
  }
  const text = (name: string) => recordText(join(dir, name));
  const target: unknown = JSON.parse(await text('target.json'));
  assert(
    isRecord(target) &&
      typeof target.cwd === 'string' &&
      target.text === input.target.text &&
      JSON.stringify(target.config) === JSON.stringify(input.target.config) &&
      target.actor === input.target.actor &&
      target.repositoryId === input.target.repositoryId,
    '旧設定・repo・実効主体が不一致です',
  );
  assert(issueText(await text('issue.stdout')) === input.original, '要求の原記録が不一致です');
  for (const index of input.target.config.setup.keys()) {
    await text(`setup-${index + 1}.stdout`);
    await text(`setup-${index + 1}.stderr`);
  }
  assert((await text('issue.json')) === input.original, '合意済みIssueの要求が変更されました');
  const test: unknown = JSON.parse(await text('test-1.target.json'));
  assert(isRecord(test), 'テスト入力manifestが不正です');
  const { targetId, ...payload } = test;
  assert(
    targetId === hash(JSON.stringify(payload)) &&
      test.issue === input.original &&
      test.stage === 'initial' &&
      test.revisionRequest === null &&
      test.baseCommit === input.head &&
      JSON.stringify(test.evidence) === '[]' &&
      JSON.stringify(test.check) === JSON.stringify(input.target.config.check) &&
      JSON.stringify(test.setup) === JSON.stringify(input.target.config.setup),
    '初回テストの入力manifest・HEAD・要求が不一致です',
  );
  const baseline = join(dir, 'test-baseline');
  assert(
    (await lstat(`${baseline}.json`)).isFile(),
    '修正前manifestの原記録が通常ファイルではありません',
  );
  const fixed = await verifyTestBaseline(baseline);
  const same = (value: unknown) => JSON.stringify(value) === JSON.stringify(fixed.files);
  assert(same(test.baseline) && same(test.files), '初回テストの修正前manifestが不一致です');
  assert(
    same(
      z
        .object({ files: z.record(z.string(), z.string()) })
        .parse(JSON.parse(await text('test-1-workspace.json'))).files,
    ),
    'テストworkspaceの入力manifestが不一致です',
  );
  const prompt = await text('test-1.prompt');
  const reports = z
    .array(z.strictObject({ path: z.string(), blob: z.string() }))
    .parse(test.reports);
  const instructions = [
    `入力: ${JSON.stringify({ targetId, stage: test.stage, baseCommit: test.baseCommit, check: test.check, setup: test.setup })}`,
    `ホスト実行証拠: ${JSON.stringify(test.evidence)}`,
    `要求:\n${input.original}`,
    researchContext(input.head, reports),
  ].join('\n');
  assert(
    prompt.slice(prompt.indexOf('\n入力: ') + 1) === instructions,
    'テスト指示の要求・参照資料と入力manifestが不一致です',
  );
  assert(typeof targetId === 'string', '入力manifestの識別値がありません');
  await actorResponse(dir, names, targetId);
  // 現在の実装checkoutは未変更の修正前入力と一致する必要がある。
  await verifyTestBaselineAt(input.cwd, fixed.files);
  const baselineHead = await checked(['git', 'rev-parse', 'HEAD'], baseline);
  const baselineBranch = await checked(['git', 'branch', '--show-current'], baseline);
  assert(
    baselineHead === input.head && baselineBranch === input.branch,
    '開始commit・branchがbaselineと不一致です',
  );
  const config = {
    cwd: input.cwd,
    targetText: input.target.text,
    review: [process.execPath, resolve(import.meta.dir, 'codex-actor.ts'), 'test', dir],
  };
  const observations = await prepareTestInterruptionObservation(input.runDirectory);
  assert(input.branch === `codex/development-${input.issue}`, '元のIssue番号とbranchが不一致です');
  const preserved = await retained({ previousRun: dir, config });
  const result: TestInterruption = {
    previousRun: dir,
    host: { cwd: target.cwd, issue: input.issue },
    head: input.head,
    branch: input.branch,
    baseline,
    config,
    remoteUrl: preserved.remoteUrl,
    retained: preserved.hash,
    observations,
    execution: { code: null, ms: null, usage: 'unknown' },
  };
  // 観測原ログは旧runと新runの外に保存し、旧runには一切書き込まない。
  await verifyObservedTestInterruption(
    result,
    resolve(input.runDirectory),
    observations,
    preserved,
  );
  return {
    record: result,
    reports,
    observations,
  };
}

export async function prepareTestInterruptionObservation(runDirectory: string) {
  const { randomUUID } = await import('node:crypto');
  const path = join(
    dirname(resolve(runDirectory)),
    `test-interruption-observation-${randomUUID()}`,
  );
  await mkdir(path, { mode: 0o700 });
  return path;
}

async function verifyTestBaselineAt(cwd: string, expected: Record<string, string>) {
  // 既存manifestの内容・全modeの計算を再利用し、旧runへmanifestを書かない。
  const actual = await testInputFiles(cwd);
  const sorted = (files: Record<string, string>) =>
    Object.entries(files).sort(([a], [b]) => a.localeCompare(b));
  assert(
    JSON.stringify(sorted(actual)) === JSON.stringify(sorted(expected)),
    '旧checkoutの成果物・入力・モードが変更されました',
  );
}
