import assert from 'node:assert/strict';
import { expect } from 'bun:test';
import { chmod, readFile, rm, symlink, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { develop } from '../../implement/orchestrator.ts';
import { testDevelopment } from '../support/development.ts';
import { object } from '../support/correction.ts';
import {
  freshTests,
  interruptedTestFixture,
  retainedTree,
  returnArgs,
  withTestReturn,
} from '../support/interrupted-test.ts';

// #428: ホストstdoutは未保存でも原actor応答は残る。外部manifestへのリンクは
// 同じ内容でも入力の照合成功にせず、新担当・実装・検証より前に止める。
for (const external of [false, true]) {
  testDevelopment(
    `初回テスト中断のstdout未保存時は${external ? '外部manifestリンクを拒否する' : '通常manifestで新担当と初回実装へ進む'}`,
    async (f) => {
      const t = await interruptedTestFixture(f);
      const manifest = `${t.prefix}.target.json`;
      const content = await readFile(manifest);
      const outside = join(t.root, 'external-manifest.json');
      await rm(`${t.prefix}.stdout`);
      if (external) {
        await writeFile(outside, content, { mode: 0o640 });
        await rm(manifest);
        await symlink(outside, manifest);
      }
      expect(await Bun.file(`${t.prefix}.stdout`).exists()).toBe(false);
      expect(await readFile(manifest)).toEqual(content);
      const old = await retainedTree(f.dir);
      const source = await retainedTree(f.repo);
      const outsideBefore = external ? await retainedTree(outside) : null;
      freshTests(f);
      let verifications = 0;
      await withTestReturn(f, t, async (baseIo) => {
        const io = {
          ...baseIo,
          verify: async (...args: Parameters<typeof baseIo.verify>) => {
            verifications++;
            return baseIo.verify(...args);
          },
        };
        if (external) {
          const error = await develop(returnArgs(f, t), io).then(
            () => null,
            (value: unknown) => value,
          );
          assert(error instanceof Error, '照合不能な入力では続行できません');
          expect(error.message).not.toMatch(
            /Unknown option|ERR_PARSE_ARGS|SyntaxError|TypeError|ReferenceError/,
          );
          expect(error.message).toMatch(
            /manifest|入力|通常ファイル|symbolic|symlink|actor|原記録|照合/i,
          );
        } else {
          const result = await develop(returnArgs(f, t), io);
          expect(result.status).toBe('verified_local');
          expect(await readFile(join(result.checkout, 'result.txt'), 'utf8')).toBe('implemented');
        }
      });
      expect(f.calls.tests).toBe(external ? 1 : 2);
      expect(f.calls.implementations).toBe(external ? 0 : 1);
      expect(verifications).toBe(external ? 0 : 1);
      expect(f.calls.pushes).toBe(0);
      expect(f.calls.publications).toBe(0);
      expect(f.calls.attachments).toBe(0);
      expect(await retainedTree(f.dir)).toEqual(old);
      expect(await retainedTree(f.repo)).toEqual(source);
      if (external) {
        assert(outsideBefore);
        expect(await retainedTree(outside)).toEqual(outsideBefore);
      }
    },
  );
}

// ホスト実行証拠の不足条件: stdoutが保存され、旧run内のsymlink自体は
// 変化せず、その参照先だけが新テストの応答時に変わる。外部参照を入口で
// 拒否する方式でも、参照先の内容・モードを固定して再照合する方式でもよい。
for (const scenario of ['regular', 'external', 'content', 'mode'] as const) {
  testDevelopment(`初回テスト復帰は保存stdout付きmanifestの${scenario}を照合する`, async (f) => {
    const t = await interruptedTestFixture(f);
    const manifest = `${t.prefix}.target.json`;
    const content = await readFile(manifest);
    const outside = join(t.root, 'external-manifest.json');
    const external = scenario !== 'regular';
    if (external) {
      await writeFile(outside, content, { mode: 0o644 });
      await rm(manifest);
      await symlink(outside, manifest);
    }
    expect(await Bun.file(`${t.prefix}.stdout`).exists()).toBe(true);
    expect(await readFile(manifest)).toEqual(content);
    const old = await retainedTree(f.dir);
    const source = await retainedTree(f.repo);
    let externalExpected = external ? await retainedTree(outside) : null;
    freshTests(f);
    const test = f.test;
    let boundary = false;
    f.test = async (...args) => {
      const response = await test(...args);
      boundary = true;
      if (scenario === 'content') {
        // 有効なJSONのまま要求との対応だけを変える。
        const input = object(JSON.parse(content.toString('utf8')));
        await writeFile(outside, JSON.stringify({ ...input, stage: 'host_return' }));
      } else if (scenario === 'mode') {
        await chmod(outside, 0o750);
      }
      if (external) {
        externalExpected = await retainedTree(outside);
      }
      // 故障注入は旧run内の内容とモードを一切変更しない。
      expect(await retainedTree(f.dir)).toEqual(old);
      return response;
    };
    let verifications = 0;
    await withTestReturn(f, t, async (baseIo) => {
      const io = {
        ...baseIo,
        verify: async (...args: Parameters<typeof baseIo.verify>) => {
          verifications++;
          return baseIo.verify(...args);
        },
      };
      const result = await develop(returnArgs(f, t), io).then(
        (value) => ({ value, error: null }),
        (error: unknown) => ({ value: null, error }),
      );
      if (scenario === 'regular' || (scenario === 'external' && boundary)) {
        assert(result.value);
        expect(result.value.status).toBe('verified_local');
        expect(f.calls.tests).toBe(2);
        expect(f.calls.implementations).toBe(1);
        expect(verifications).toBe(1);
      } else {
        assert(result.error instanceof Error, '照合不能または参照先変化では続行できません');
        expect(result.error.message).not.toMatch(
          /Unknown option|ERR_PARSE_ARGS|SyntaxError|TypeError|ReferenceError/,
        );
        expect(result.error.message).toMatch(
          /manifest|入力|通常ファイル|symbolic|symlink|原記録|照合|変更|不一致|mode|モード|保全/i,
        );
        expect(f.calls.tests).toBe(boundary ? 2 : 1);
        expect(f.calls.implementations).toBe(0);
        expect(verifications).toBe(0);
      }
    });
    expect(await retainedTree(f.dir)).toEqual(old);
    expect(await retainedTree(f.repo)).toEqual(source);
    if (external) {
      assert(externalExpected);
      expect(await retainedTree(outside)).toEqual(externalExpected);
    }
    expect(f.calls.pushes).toBe(0);
    expect(f.calls.publications).toBe(0);
    expect(f.calls.attachments).toBe(0);
  });
}
