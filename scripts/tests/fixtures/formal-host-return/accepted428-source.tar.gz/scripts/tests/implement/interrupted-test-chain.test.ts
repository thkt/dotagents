import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { expect } from 'bun:test';
import { snapshot } from '../../implement/correction.ts';
import { develop } from '../../implement/orchestrator.ts';
import { object } from '../support/correction.ts';
import { testDevelopment } from '../support/development.ts';
import { expectTestStage } from '../support/test-stage.ts';
import {
  freshTests,
  interruptedTestFixture,
  retainedTree,
  returnArgs,
  withTestReturn,
} from '../support/interrupted-test.ts';

// #428と固定修正要求: 中断入口の再試行と、正式なホスト検証後の再評価を区別する。
// 証拠は各停止時点のsourceを指す模擬観測であり、実適用の成功を主張しない。
async function hostArgs(root: string, prior: string, cwd: string, name: string) {
  const log = join(root, `${name}.stdout`);
  const evidence = join(root, `${name}.json`);
  const content = '模擬ホスト観測。実サービス・実モデルは未確認。';
  await writeFile(log, content);
  await writeFile(
    evidence,
    JSON.stringify({
      status: 'passed',
      source: await snapshot(cwd),
      findings: content,
      logs: [{ path: log, sha256: createHash('sha256').update(content).digest('hex') }],
    }),
  );
  return [
    '99',
    '--repo',
    cwd,
    '--host-run',
    prior,
    '--host-evidence',
    evidence,
    '--run-dir',
    join(root, name),
    '--no-publish',
  ];
}

testDevelopment(
  '初回テスト中断の正式なホスト復帰が再停止しても追加の復帰を連鎖しない',
  async (f) => {
    const normalImplement = f.implement;
    const t = await interruptedTestFixture(f);
    const old = await retainedTree(f.dir);
    const source = await retainedTree(f.repo);
    freshTests(f);
    f.implement = async (...args) => {
      const reply = await normalImplement(...args);
      reply.stdout = JSON.stringify({ status: 'needs_host', findings: '模擬ホスト検証待ち' });
      await writeFile(`${args[4]}.stdout`, reply.stdout);
      return reply;
    };
    await withTestReturn(f, t, async (baseIo) => {
      let verificationEntries = 0;
      const io = {
        ...baseIo,
        verify: async (...args: Parameters<typeof baseIo.verify>) => {
          verificationEntries++;
          return baseIo.verify(...args);
        },
      };
      await assert.rejects(() => develop(returnArgs(f, t), io), /Host verification required/);
      await expectHostStop(t.dir, 'initial implementation');
      const stopped = object(JSON.parse(await readFile(join(t.dir, 'result.json'), 'utf8')));
      assert(typeof stopped.checkout === 'string');
      const cwd = stopped.checkout;
      const first = await retainedTree(t.dir);
      freshTests(f, 'needs_host');
      const secondArgs = await hostArgs(t.root, t.dir, cwd, 'stopped-host-return');
      await assert.rejects(() => develop(secondArgs, io), /Host verification required/);
      const returned = join(t.root, 'stopped-host-return');
      await expectHostStop(returned, 'independent test authoring');
      expect(f.calls.tests).toBe(3);
      expect(f.calls.implementations).toBe(1);
      expect(verificationEntries).toBe(0);
      expect(await readFile(join(cwd, 'result.txt'), 'utf8')).toBe('implemented');
      const second = await retainedTree(returned);
      // 証拠が揃っていても、初回テスト中断に由来する復帰の連鎖は許可しない。
      // 上の正常対照と異なり、すでに一度正式なホスト復帰を実行している。
      freshTests(f);
      const thirdArgs = await hostArgs(t.root, returned, cwd, 'forbidden-further-host-return');
      const calls = { ...f.calls };
      const error = await develop(thirdArgs, io).then(
        () => null,
        (value: unknown) => value,
      );
      assert(error instanceof Error, '追加の復帰は拒否が必要です');
      expect(error.message).not.toMatch(
        /Unknown option|ERR_PARSE_ARGS|SyntaxError|TypeError|ReferenceError|Host verification required/,
      );
      expect(error.message).toMatch(/初回テスト.*復帰|連鎖|追加.*復帰|chain/i);
      expect(f.calls).toEqual(calls);
      expect(verificationEntries).toBe(0);
      expect(existsSync(join(t.root, 'forbidden-further-host-return', 'result.json'))).toBe(false);
      expect(await retainedTree(returned)).toEqual(second);
      expect(await retainedTree(t.dir)).toEqual(first);
    });
    expect(await retainedTree(f.dir)).toEqual(old);
    expect(await retainedTree(f.repo)).toEqual(source);
    expect(f.calls.pushes).toBe(0);
    expect(f.calls.publications).toBe(0);
    expect(f.calls.attachments).toBe(0);
  },
);

async function expectHostStop(dir: string, operation: string) {
  expect(object(JSON.parse(await readFile(join(dir, 'result.json'), 'utf8')))).toMatchObject({
    status: 'stopped',
    reasonCode: 'host_verification_required',
    operation,
    publication: 'not_attempted',
  });
  expect(existsSync(join(dir, 'host-stop.json'))).toBe(true);
}

for (const firstStop of ['test', 'implementation'] as const) {
  testDevelopment(
    `初回テスト中断の${firstStop}停止後は正式なホスト検証から評価へ戻る`,
    async (f) => {
      const normalTest = f.test;
      const normalImplement = f.implement;
      const t = await interruptedTestFixture(f);
      const old = await retainedTree(f.dir);
      const source = await retainedTree(f.repo);
      freshTests(f, firstStop === 'test' ? 'needs_host' : 'unnecessary');
      if (firstStop === 'implementation') {
        f.implement = async (...args) => {
          const reply = await normalImplement(...args);
          reply.stdout = JSON.stringify({
            status: 'needs_host',
            findings: '模擬の追加ホスト検証待ち',
          });
          await writeFile(`${args[4]}.stdout`, reply.stdout);
          return reply;
        };
      }
      await withTestReturn(f, t, async (baseIo) => {
        let verificationEntries = 0;
        const io = {
          ...baseIo,
          verify: async (...args: Parameters<typeof baseIo.verify>) => {
            verificationEntries++;
            return baseIo.verify(...args);
          },
        };
        // 正常な対照: 有効な中断から新しい独立テスト、必要なら未実行の初回実装へ到達する。
        await assert.rejects(() => develop(returnArgs(f, t), io), /Host verification required/);
        await expectHostStop(
          t.dir,
          firstStop === 'test' ? 'independent test authoring' : 'initial implementation',
        );
        expect(f.calls.tests).toBe(2);
        expect(f.calls.implementations).toBe(firstStop === 'test' ? 0 : 1);
        expect(verificationEntries).toBe(0);
        const firstResult = object(JSON.parse(await readFile(join(t.dir, 'result.json'), 'utf8')));
        assert(typeof firstResult.checkout === 'string');
        const cwd = firstResult.checkout;
        const first = await retainedTree(t.dir);
        const checkout = await retainedTree(cwd);
        f.implement = normalImplement;
        // 元版CLIガイド「ホスト検証後の再評価」に従う。新しい現在版の証拠を
        // 明示した復帰では、未実行の初回実装だけを実行し、check・評価へ進む。
        f.test = async (...args) => {
          assert(args[4]);
          await expectTestStage(args[2], args[4], 'host_return');
          expect(args[2]).not.toContain('OLD_PRIVATE_JUDGMENT');
          // 実装済みのcheckoutとは別に、独立テストは固定した修正前の版を使う。
          expect(await readFile(join(args[1], 'result.txt'), 'utf8')).toBe('old');
          return normalTest(...args);
        };
        const secondArgs = await hostArgs(t.root, t.dir, cwd, 'verified-host-return');
        // 証拠のない再試行は正式な復帰ではない。新入口の再適用も引き続き拒否する。
        const retry = returnArgs(f, t);
        retry[retry.indexOf('--test-interrupted-run') + 1] = t.dir;
        retry[retry.indexOf('--run-dir') + 1] = join(t.root, 'forbidden-retry');
        const calls = { ...f.calls };
        await assert.rejects(() => develop(retry, io), /復帰|return|履歴|対象|終端|result|保存/i);
        expect(f.calls).toEqual(calls);
        expect(verificationEntries).toBe(0);
        const result = await develop(secondArgs, io);
        expect(result.status).toBe('verified_local');
        expect(result.checkout).toBe(cwd);
        expect(f.calls.tests).toBe(3);
        expect(f.calls.implementations).toBe(1);
        expect(verificationEntries).toBe(1);
        expect(await readFile(join(cwd, 'result.txt'), 'utf8')).toBe('implemented');
        const returned = join(t.root, 'verified-host-return');
        const state = object(
          JSON.parse(await readFile(join(returned, 'verification/state.json'), 'utf8')),
        );
        expect(state).toMatchObject({
          checks: 1,
          review: 1,
          repair: 0,
          result: 'ready_for_human_review',
        });
        const config = object(
          JSON.parse(await readFile(join(returned, 'verification-config.json'), 'utf8')),
        );
        const stoppedConfig = object(
          JSON.parse(await readFile(join(t.dir, 'verification-config.json'), 'utf8')),
        );
        expect(config.baseCommit).toBe(stoppedConfig.baseCommit);
        expect(object(config.hostReturn).previousRun).toBe(t.dir);
        const reviewTarget = object(
          JSON.parse(await readFile(join(returned, 'verification/review-1.target.json'), 'utf8')),
        );
        expect(object(reviewTarget.hostReturn).previousRun).toBe(t.dir);
        const evidencePath = secondArgs[secondArgs.indexOf('--host-evidence') + 1];
        assert(evidencePath);
        expect(object(reviewTarget.hostReturn).evidence).toEqual({
          path: evidencePath,
          sha256: createHash('sha256')
            .update(await readFile(evidencePath))
            .digest('hex'),
        });
        // 既存のhostReturnは旧設定をhash付きrecordsとして参照する。
        // 新設定への同じフィールドの複製を契約として要求しない。
        const returnedHistory = object(config.hostReturn);
        assert(Array.isArray(returnedHistory.records));
        expect(returnedHistory.records).toContainEqual({
          path: join(t.dir, 'verification-config.json'),
          sha256: createHash('sha256')
            .update(await readFile(join(t.dir, 'verification-config.json')))
            .digest('hex'),
        });
        const interruption = object(stoppedConfig.testInterruption);
        expect(interruption.previousRun).toBe(f.dir);
        expect(object(interruption.execution)).toMatchObject({
          usage: 'unknown',
          code: null,
          ms: null,
        });
        const recordsOnly = (tree: Record<string, unknown>) =>
          Object.fromEntries(
            Object.entries(tree).filter(([path]) => path !== cwd && !path.startsWith(`${cwd}/`)),
          );
        expect(recordsOnly(await retainedTree(t.dir))).toEqual(recordsOnly(first));
        if (firstStop === 'implementation') {
          expect(await retainedTree(cwd)).toEqual(checkout);
        }
      });
      expect(await retainedTree(f.dir)).toEqual(old);
      expect(await retainedTree(f.repo)).toEqual(source);
      expect(f.calls.pushes).toBe(0);
      expect(f.calls.publications).toBe(0);
      expect(f.calls.attachments).toBe(0);
    },
  );
}
