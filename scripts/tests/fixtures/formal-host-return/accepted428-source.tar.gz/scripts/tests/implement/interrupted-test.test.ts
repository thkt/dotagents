import assert from 'node:assert/strict';
import { expect } from 'bun:test';
import { chmod, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { dirname, join } from 'node:path';
import { develop } from '../../implement/orchestrator.ts';
import { command } from '../../shared/process.ts';
import { gitOutput, issue, testDevelopment } from '../support/development.ts';
import { object } from '../support/correction.ts';
import {
  freshTests,
  interruptedTestFixture,
  retainedTree,
  returnArgs,
  withTestReturn,
} from '../support/interrupted-test.ts';
import type { InterruptedTest, Observation } from '../support/interrupted-test.ts';
import type { DevelopmentFixture } from '../support/development.ts';

// 保存失敗以外が正常である対照。初回実装・検証のfixture接続を確認する。
testDevelopment('初回テスト中断の正常対照は通常初回を実装できる', async (f) => {
  const result = await develop([...f.args, '--no-publish'], f.io);
  expect(result.status).toBe('verified_local');
  expect(f.calls.tests).toBe(1);
  expect(f.calls.implementations).toBe(1);
  expect(f.calls.pushes).toBe(0);
});

testDevelopment('初回テスト中断fixtureは原応答だけを残し採用・実装していない', async (f) => {
  const t = await interruptedTestFixture(f);
  expect(await readFile(join(dirname(t.actorPath), 'final.json'), 'utf8')).toBe(
    await readFile(`${t.prefix}.stdout`, 'utf8'),
  );
  expect(object(JSON.parse(await readFile(`${t.prefix}.target.json`, 'utf8'))).stage).toBe(
    'initial',
  );
});

testDevelopment(
  '初回テスト中断から新しい独立判断の後だけ初回実装とcheck・評価へ進む',
  async (f) => {
    const t = await interruptedTestFixture(f);
    const retained = await retainedTree(f.dir);
    const original = await retainedTree(f.repo);
    freshTests(f);
    await withTestReturn(f, t, async (io, observations) => {
      const result = await develop(returnArgs(f, t), io);
      expect(result.status).toBe('verified_local');
      expect(result.checkout).not.toBe(t.cwd);
      expect(f.calls.tests).toBe(2);
      expect(f.calls.implementations).toBe(1);
      expect(observations).toContain('process');
      expect(observations).toContain('remote');
      expect(observations).toContain('publication');
      const state = object(
        JSON.parse(await readFile(join(t.dir, 'verification/state.json'), 'utf8')),
      );
      expect(state).toMatchObject({
        checks: 1,
        review: 1,
        repair: 0,
        result: 'ready_for_human_review',
      });
      const tests = await readFile(join(t.dir, 'test-records.json'), 'utf8');
      expect(tests).not.toContain(t.prefix);
      expect(tests).not.toContain('unadopted.test.js');
      expect(tests).not.toContain('OLD_PRIVATE_JUDGMENT');
      expect(await readFile(join(result.checkout, 'result.txt'), 'utf8')).toBe('implemented');
      // 新runから旧runと原actorを辿れ、不明量を成功・全量へ補完しない。
      const paths = Object.keys(await retainedTree(t.dir)).filter((path) => path.endsWith('.json'));
      const records = (await Promise.all(paths.map((path) => readFile(path, 'utf8')))).join('\n');
      expect(records).toContain(f.dir);
      expect(records).toContain(t.actorPath);
      expect(records).toMatch(/unknown|unrecorded|不明|未記録/i);
      const interruption = object(
        JSON.parse(await readFile(join(t.dir, 'test-interruption.json'), 'utf8')),
      );
      const config = object(
        JSON.parse(await readFile(join(t.dir, 'verification-config.json'), 'utf8')),
      );
      // actor応答の存在やusageの不明表示だけでは、ホストの未保存値を補完できない。
      for (const record of [interruption, object(config.testInterruption)]) {
        expect(record.previousRun).toBe(f.dir);
        expect(record.host).toEqual({ cwd: f.repo, issue: '99' });
        const execution = object(record.execution);
        expect(execution.usage).toBe('unknown');
        expect(execution.code).toBeNull();
        expect(execution.ms).toBeNull();
      }
    });
    expect(await retainedTree(f.dir)).toEqual(retained);
    expect(await retainedTree(f.repo)).toEqual(original);
    expect(f.calls.pushes).toBe(0);
    expect(f.calls.publications).toBe(0);
  },
);

testDevelopment('初回テスト復帰は新担当のprepared成果物だけを初回実装へ渡す', async (f) => {
  const t = await interruptedTestFixture(f);
  const old = await retainedTree(f.dir);
  const original = await retainedTree(f.repo);
  const name = 'fresh-independent.test.js';
  const content =
    "import {readFileSync} from 'node:fs'; if(readFileSync('result.txt','utf8')!=='implemented')process.exit(1);\n";
  freshTests(f);
  const independent = f.test;
  f.test = async (...args) => {
    // 固定版・要求・stage・旧担当の非混入は既存の正常対照と同じ条件で照合する。
    const reply = await independent(...args);
    const response = object(JSON.parse(reply.stdout));
    await writeFile(join(args[1], name), content, { mode: 0o750 });
    const red = await command([process.execPath, name], args[1], '', 10000);
    expect(red.code).toBe(1);
    expect(red.timedOut).toBe(false);
    expect(red.stderr).toBe('');
    reply.stdout = JSON.stringify({ ...response, status: 'prepared', files: [name] });
    await writeFile(`${args[4]}.stdout`, reply.stdout);
    return reply;
  };
  const implement = f.implement;
  let transferred = false;
  f.implement = async (...args) => {
    expect(await readFile(join(args[1], name), 'utf8')).toBe(content);
    expect(await Bun.file(join(args[1], 'unadopted.test.js')).exists()).toBe(false);
    transferred = true;
    return implement(...args);
  };
  await withTestReturn(f, t, async (io) => {
    const result = await develop(returnArgs(f, t), io);
    expect(result.status).toBe('verified_local');
    expect(transferred).toBe(true);
    expect(f.calls.tests).toBe(2);
    expect(f.calls.implementations).toBe(1);
    expect(await readFile(join(result.checkout, name), 'utf8')).toBe(content);
    const adopted = await readFile(join(t.dir, 'test-records.json'), 'utf8');
    expect(adopted).toContain(name);
    expect(adopted).not.toContain('unadopted.test.js');
    expect(adopted).not.toContain('OLD_PRIVATE_JUDGMENT');
    const check = await command([process.execPath, name], result.checkout, '', 10000);
    expect(check.code).toBe(0);
    expect(check.timedOut).toBe(false);
  });
  expect(await retainedTree(f.dir)).toEqual(old);
  expect(await retainedTree(f.repo)).toEqual(original);
  expect(f.calls.pushes).toBe(0);
  expect(f.calls.publications).toBe(0);
});

testDevelopment('未保存の初回テスト中断は別名の通常起動による迂回を拒否する', async (f) => {
  const t = await interruptedTestFixture(f);
  const old = await retainedTree(f.dir);
  const original = await retainedTree(f.repo);
  freshTests(f);
  await assert.rejects(
    () =>
      develop(
        ['99', '--repo', t.cwd, '--run-dir', join(t.root, 'ordinary-alias'), '--no-publish'],
        f.io,
      ),
    /unfinished|incomplete|active|未完了|中断|branch named .* already exists/i,
  );
  expect(f.calls.tests).toBe(1);
  expect(f.calls.implementations).toBe(0);
  expect(f.calls.verificationEntries).toBe(0);
  expect(f.calls.pushes).toBe(0);
  expect(f.calls.publications).toBe(0);
  expect(await retainedTree(f.dir)).toEqual(old);
  expect(await retainedTree(f.repo)).toEqual(original);
});

type Fault = {
  name: string;
  reason: RegExp;
  change?: (f: DevelopmentFixture, t: InterruptedTest) => Promise<void>;
  observation?: Observation;
};
const faults: Fault[] = [
  {
    name: '保存promptの要求本文だけの変化',
    reason: /要求|issue|prompt|指示|不一致|照合/i,
    change: async (_f, t) => {
      const path = `${t.prefix}.prompt`;
      const prompt = await readFile(path, 'utf8');
      const original = `要求:\n${issue}`;
      const changedIssue = JSON.stringify({ ...object(JSON.parse(issue)), body: '別の要求' });
      expect(prompt.split(original)).toHaveLength(2);
      // 入力manifest・取得Issue・actor原記録を保ち、保存した要求だけを違える。
      await writeFile(path, prompt.replace(original, `要求:\n${changedIssue}`));
      expect(await readFile(path, 'utf8')).not.toBe(prompt);
    },
  },
  {
    name: '修正前manifest欠落',
    reason: /baseline|manifest|入力|ENOENT/i,
    change: async (f) => {
      await rm(join(f.dir, 'test-baseline.json'));
    },
  },

  {
    name: '入力manifest欠落',
    reason: /baseline|manifest|入力|ENOENT/i,
    change: async (_f, t) => {
      await rm(`${t.prefix}.target.json`);
    },
  },
  {
    name: '入力manifest変化',
    reason: /manifest|入力|target|hash|変更|不一致/i,
    change: async (_f, t) => {
      const input = object(JSON.parse(await readFile(`${t.prefix}.target.json`, 'utf8')));
      await writeFile(
        `${t.prefix}.target.json`,
        JSON.stringify({ ...input, stage: 'host_return' }),
      );
    },
  },
  {
    name: '実効主体変更',
    reason: /actor|主体|identity|不一致|changed/i,
    change: async (f) => {
      const github = f.github;
      f.github = async (...args) => {
        const reply = await github(...args);
        return args[0][1] === 'api' && args[0][2] === 'user'
          ? { ...reply, stdout: JSON.stringify({ login: 'another-operator' }) }
          : reply;
      };
    },
  },
  {
    name: 'repository ID変更',
    reason: /repository|リポジトリ|対象|不一致|changed/i,
    change: async (f) => {
      const github = f.github;
      f.github = async (...args) => {
        const reply = await github(...args);
        if (args[0][1] !== 'api' || args[0][2] !== `repos/${f.settings.repository}`) {
          return reply;
        }
        const repository = object(JSON.parse(reply.stdout));
        return { ...reply, stdout: JSON.stringify({ ...repository, id: 456 }) };
      };
    },
  },
  {
    name: '修正前baseline変化',
    reason: /baseline|修正前|入力|変更|不一致/i,
    change: async (f) => {
      await writeFile(join(f.dir, 'test-baseline/result.txt'), 'changed');
    },
  },
  {
    name: '旧checkout変化',
    reason: /source|成果物|checkout|変更|不一致/i,
    change: async (_f, t) => {
      await writeFile(join(t.cwd, 'result.txt'), 'changed');
    },
  },
  {
    name: 'actor原記録欠落',
    reason: /actor|runtime|原記録|欠落|ENOENT/i,
    change: async (_f, t) => {
      await rm(t.actorPath);
    },
  },
  {
    name: 'actor対応違い',
    reason: /actor|prefix|対応|照合/i,
    change: async (_f, t) => {
      const actor = object(JSON.parse(await readFile(t.actorPath, 'utf8')));
      await writeFile(t.actorPath, JSON.stringify({ ...actor, hostPrefix: 'other-test' }));
    },
  },
  {
    name: 'actor応答不一致',
    reason: /応答|response|final|不一致|照合/i,
    change: async (_f, t) => {
      await writeFile(join(dirname(t.actorPath), 'final.json'), '{}');
    },
  },
  {
    name: 'actor原応答欠落',
    reason: /actor|応答|final|原記録|欠落|ENOENT/i,
    change: async (_f, t) => {
      await rm(join(dirname(t.actorPath), 'final.json'));
    },
  },
  {
    name: 'actor実行記録欠落',
    reason: /actor|events|実行|原記録|欠落|ENOENT/i,
    change: async (_f, t) => {
      await rm(join(dirname(t.actorPath), 'events.jsonl'));
    },
  },
  {
    name: 'actor実行記録と原応答の不一致',
    reason: /actor|events|実行|原記録|応答|不一致|照合/i,
    change: async (_f, t) => {
      const path = join(dirname(t.actorPath), 'events.jsonl');
      const original = await readFile(path, 'utf8');
      const final = await readFile(join(dirname(t.actorPath), 'final.json'), 'utf8');
      const events = original
        .trimEnd()
        .split('\n')
        .map((line) => object(JSON.parse(line)));
      const completed = events.filter((event) => event.type === 'item.completed');
      expect(completed).toHaveLength(1);
      const event = completed[0];
      assert(event);
      const item = object(event.item);
      expect(item.text).toBe(final);
      // 有効なJSON・完了イベント・usageと保存原応答を保ち、応答の対応だけを違える。
      const response = object(JSON.parse(final));
      item.text = JSON.stringify({ ...response, findings: '別の呼出しの応答' });
      expect(item.text).not.toBe(final);
      await writeFile(path, events.map((value) => JSON.stringify(value)).join('\n') + '\n');
    },
  },
  {
    name: 'ホスト実行結果あり',
    reason: /execution|実行|対象|保存|結果/i,
    change: async (_f, t) => {
      await writeFile(
        `${t.prefix}.execution.json`,
        JSON.stringify({ code: 0, timedOut: false, ms: 123 }),
      );
    },
  },
  {
    name: '採用済みテストあり',
    reason: /test|採用|対象|テスト|記録/i,
    change: async (f, t) => {
      await writeFile(
        join(f.dir, 'test-records.json'),
        JSON.stringify([
          { prefix: t.prefix, targetId: 'adopted', stdoutHash: 'a'.repeat(64), files: {} },
        ]),
      );
    },
  },
  {
    name: 'ホスト保存済みテスト判断あり',
    reason: /test|判断|採用|対象|テスト|保存|記録/i,
    change: async (_f, t) => {
      await writeFile(`${t.prefix}.json`, await readFile(`${t.prefix}.stdout`));
    },
  },
  {
    name: '実装原記録あり',
    reason: /implementation|実装|対象|履歴/i,
    change: async (f) => {
      await writeFile(
        join(f.dir, 'implementation.stdout'),
        '{"status":"repaired","findings":"done"}',
      );
    },
  },
  {
    name: 'check履歴あり',
    reason: /check|検証|対象|履歴/i,
    change: async (f) => {
      await mkdir(join(f.dir, 'verification'));
      await writeFile(join(f.dir, 'verification/check-1.stdout'), 'passed');
    },
  },
  {
    name: '独立評価履歴あり',
    reason: /review|評価|検証|対象|履歴/i,
    change: async (f) => {
      await mkdir(join(f.dir, 'verification'));
      await writeFile(join(f.dir, 'verification/review-1.stdout'), '{}');
    },
  },
  {
    name: '追加修正履歴あり',
    reason: /repair|修正|検証|対象|履歴/i,
    change: async (f) => {
      await mkdir(join(f.dir, 'verification'));
      await writeFile(join(f.dir, 'verification/repair-1.stdout'), '{}');
    },
  },
  {
    name: '他の復帰履歴あり',
    reason: /return|復帰|履歴|対象/i,
    change: async (f) => {
      await writeFile(join(f.dir, 'review-return.json'), '{}');
    },
  },
  {
    name: 'lockあり',
    reason: /lock|ロック/i,
    change: async (_f, t) => {
      const gitDir = await gitOutput(t.cwd, 'rev-parse', '--absolute-git-dir');
      await writeFile(join(gitDir, 'index.lock'), 'fixture: active Git lock', { mode: 0o600 });
    },
  },
  {
    name: 'Issue変更',
    reason: /issue|要求|不一致|changed/i,
    change: async (f) => {
      const github = f.github;
      f.github = async (...args) =>
        args[0][1] === 'issue'
          ? {
              code: 0,
              stdout: JSON.stringify({ ...JSON.parse(issue), body: '別の要求' }),
              stderr: '',
              timedOut: false,
              ms: 1,
            }
          : github(...args);
    },
  },
  {
    name: 'branch変更',
    reason: /branch|HEAD|不一致/i,
    change: async (_f, t) => {
      await gitOutput(t.cwd, 'switch', '-c', 'other');
    },
  },
  {
    name: '開始commitからHEAD変更',
    reason: /commit|HEAD|開始|不一致|changed/i,
    change: async (_f, t) => {
      await gitOutput(t.cwd, 'commit', '--allow-empty', '-m', 'fixture');
    },
  },
  {
    name: '旧checkoutのモード変更',
    reason: /source|成果物|checkout|mode|モード|変更|不一致/i,
    change: async (_f, t) => {
      await chmod(join(t.cwd, 'result.txt'), 0o750);
    },
  },
  {
    name: '設定変更',
    reason: /config|設定|target|不一致|changed/i,
    change: async (_f, t) => {
      await writeFile(join(t.cwd, '.dotagents.json'), '{}');
    },
  },
  { name: '通常ホスト稼働中', reason: /process|プロセス|稼働|PID/i, observation: 'host' },
  ...(['host_relative', 'host_omitted', 'host_symlink'] as const).map((observation) => ({
    name: `${observation}で指定した同じIssueの旧ホスト稼働中`,
    reason: /process|プロセス|稼働|PID|照合|解決|特定/i,
    observation,
  })),
  {
    name: '通常ホストの祖先も稼働中',
    reason: /process|プロセス|稼働|PID/i,
    observation: 'ancestor_host',
  },
  {
    name: '祖先以外の復帰CLI稼働中',
    reason: /process|プロセス|稼働|PID/i,
    observation: 'sibling_return',
  },
  { name: 'プロセス列不正', reason: /process|プロセス|列|照合/i, observation: 'malformed' },
  { name: '稼働中', reason: /process|プロセス|稼働|PID/i, observation: 'live' },
  { name: 'プロセス照合不能', reason: /process|プロセス|一覧|照合/i, observation: 'unreadable' },
  { name: 'remote公開済み', reason: /remote|ref|公開|branch/i, observation: 'remote' },
  { name: '閉じたPRあり', reason: /PR|公開|pull|照合/i, observation: 'closed_pr' },
  { name: '公開状態不明', reason: /GitHub|観測|公開|取得|failed/i, observation: 'github_failed' },
];

for (const fault of faults) {
  testDevelopment(`初回テスト中断は${fault.name}を理由付きで拒否し保全する`, async (f) => {
    const t = await interruptedTestFixture(f);
    await fault.change?.(f, t);
    const before = await retainedTree(f.dir);
    freshTests(f);
    await withTestReturn(
      f,
      t,
      async (io) => {
        const error = await develop(returnArgs(f, t), io).then(
          () => null,
          (value: unknown) => value,
        );
        assert(error instanceof Error, '対象条件の拒否が必要です');
        expect(error.message).not.toMatch(
          /Unknown option|ERR_PARSE_ARGS|SyntaxError|TypeError|ReferenceError/,
        );
        expect(error.message).toMatch(fault.reason);
      },
      fault.observation,
    );
    expect(f.calls.tests).toBe(1);
    expect(f.calls.implementations).toBe(0);
    expect(f.calls.pushes).toBe(0);
    expect(f.calls.publications).toBe(0);
    expect(await retainedTree(f.dir)).toEqual(before);
    if (fault.name === 'lockあり') {
      const gitDir = await gitOutput(t.cwd, 'rev-parse', '--absolute-git-dir');
      expect(await readFile(join(gitDir, 'index.lock'), 'utf8')).toBe('fixture: active Git lock');
    }
  });
}

for (const status of ['needs_human', 'needs_host', 'invalid']) {
  testDevelopment(`復帰した初回テストの${status}を初回実装の許可にしない`, async (f) => {
    const t = await interruptedTestFixture(f);
    const before = await retainedTree(f.dir);
    freshTests(f, status);
    await withTestReturn(f, t, async (io) => {
      await assert.rejects(
        () => develop(returnArgs(f, t), io),
        /テスト|test|host|human|準備|Invalid|invalid/i,
      );
    });
    expect(f.calls.tests).toBe(2);
    expect(f.calls.implementations).toBe(0);
    expect(await retainedTree(f.dir)).toEqual(before);
  });
}

// モード変更は元の期待値が保存されているbaselineとinput manifestで検出する。
testDevelopment('初回テスト中断はbaselineのモードだけの変化も拒否する', async (f) => {
  const t = await interruptedTestFixture(f);
  await chmod(join(f.dir, 'test-baseline/result.txt'), 0o750);
  const before = await retainedTree(f.dir);
  await withTestReturn(f, t, async (io) => {
    await assert.rejects(
      () => develop(returnArgs(f, t), io),
      /baseline|モード|mode|入力|変更|不一致/i,
    );
  });
  expect(f.calls.tests).toBe(1);
  expect(f.calls.implementations).toBe(0);
  expect(await retainedTree(f.dir)).toEqual(before);
});

// 既存入口は終端の初回評価中断だけを扱い、今回の対象へ拡張しない。
testDevelopment('既存の初回評価中断入口は未保存の初回テストを引き受けない', async (f) => {
  const t = await interruptedTestFixture(f);
  const before = await retainedTree(f.dir);
  await withTestReturn(f, t, async (io) => {
    const args = returnArgs(f, t).map((arg) =>
      arg === '--test-interrupted-run' ? '--interrupted-run' : arg,
    );
    await assert.rejects(() => develop(args, io), /result|終端|中断|対象|ENOENT/i);
  });
  expect(f.calls.tests).toBe(1);
  expect(f.calls.implementations).toBe(0);
  expect(await retainedTree(f.dir)).toEqual(before);
});

testDevelopment('初回テスト復帰は自身の再停止を自動再試行せず連鎖も拒否する', async (f) => {
  const t = await interruptedTestFixture(f);
  const old = await retainedTree(f.dir);
  freshTests(f, 'needs_human');
  await withTestReturn(f, t, async (io) => {
    await assert.rejects(() => develop(returnArgs(f, t), io), /人|human|テスト/i);
    expect(f.calls.tests).toBe(2);
    expect(f.calls.implementations).toBe(0);
    const stopped = await retainedTree(t.dir);
    const next = returnArgs(f, t);
    const origin = next.indexOf('--test-interrupted-run') + 1;
    const destination = next.indexOf('--run-dir') + 1;
    next[origin] = t.dir;
    next[destination] = join(t.root, 'test-return-again');
    await assert.rejects(() => develop(next, io), /復帰|return|履歴|対象|終端|result|保存/i);
    expect(f.calls.tests).toBe(2);
    expect(f.calls.implementations).toBe(0);
    expect(await retainedTree(t.dir)).toEqual(stopped);
  });
  expect(await retainedTree(f.dir)).toEqual(old);
});

for (const boundary of ['test', 'implementation'] as const) {
  for (const defect of ['content', 'mode'] as const) {
    testDevelopment(
      `初回テスト復帰は${boundary}後の旧応答${defect}変化を受け入れない`,
      async (f) => {
        const t = await interruptedTestFixture(f);
        freshTests(f);
        let injected: Record<string, unknown> | undefined;
        const change = async () => {
          if (defect === 'content') {
            await writeFile(`${t.prefix}.stdout`, '{}');
          } else {
            await chmod(`${t.prefix}.stdout`, 0o750);
          }
          injected = await retainedTree(f.dir);
        };
        if (boundary === 'test') {
          const test = f.test;
          f.test = async (...args) => {
            const response = await test(...args);
            await change();
            return response;
          };
        } else {
          const implement = f.implement;
          f.implement = async (...args) => {
            const response = await implement(...args);
            await change();
            return response;
          };
        }
        await withTestReturn(f, t, async (io) => {
          await assert.rejects(
            () => develop(returnArgs(f, t), io),
            /応答|原記録|変更|不一致|mode|hash|保全/i,
          );
        });
        assert(injected, '狙った工程への到達が必要です');
        expect(f.calls.tests).toBe(2);
        expect(f.calls.implementations).toBe(boundary === 'test' ? 0 : 1);
        expect(await Bun.file(join(t.dir, 'verification/check-1.stdout')).exists()).toBe(false);
        expect(await retainedTree(f.dir)).toEqual(injected);
        expect(f.calls.pushes).toBe(0);
      },
    );
  }
}

// 明示した復帰CLI自身の祖先と無関係なコマンドは、旧ホストの稼働と区別する。
for (const observation of ['ancestor_return', 'unrelated', 'foreign_host'] as const) {
  testDevelopment(`初回テスト復帰は${observation}を旧ホストと混同しない`, async (f) => {
    const t = await interruptedTestFixture(f);
    const before = await retainedTree(f.dir);
    freshTests(f);
    await withTestReturn(
      f,
      t,
      async (io, observations) => {
        const result = await develop(returnArgs(f, t), io);
        expect(result.status).toBe('verified_local');
        expect(observations).toContain('process');
        expect(f.calls.tests).toBe(2);
        expect(f.calls.implementations).toBe(1);
      },
      observation,
    );
    expect(await retainedTree(f.dir)).toEqual(before);
    expect(f.calls.pushes).toBe(0);
    expect(f.calls.publications).toBe(0);
  });
}
