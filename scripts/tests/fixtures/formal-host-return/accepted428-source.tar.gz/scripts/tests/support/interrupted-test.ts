import assert from 'node:assert/strict';
import { expect, spyOn } from 'bun:test';
import * as fs from 'node:fs/promises';
import * as processModule from '../../shared/process.ts';
import { createHash } from 'node:crypto';
import { dirname, join, relative } from 'node:path';
import { develop } from '../../implement/orchestrator.ts';
import { run } from '../../implement/correction.ts';
import { testReplySchema } from '../../implement/test-author.ts';
import { object, reviewReplySource } from './correction.ts';
import { issue, ok } from './development.ts';
import type { DevelopmentFixture } from './development.ts';
import { saveActorRecord } from './actor-records.ts';
import { initializeTarget } from './target.ts';

// 内容と全permission bitを観測する。Gitの実行bitだけの比較では代用しない。
export async function retainedTree(dir: string): Promise<Record<string, unknown>> {
  const result: Record<string, unknown> = {};
  async function visit(path: string) {
    const info = await fs.lstat(path);
    result[path] = {
      mode: info.mode,
      content: info.isFile()
        ? createHash('sha256')
            .update(await fs.readFile(path))
            .digest('hex')
        : info.isSymbolicLink()
          ? await fs.readlink(path)
          : null,
    };
    if (info.isDirectory()) {
      for (const name of (await fs.readdir(path)).sort()) {
        // 共通Git object storeは他の隔離checkout作成でも変化する。
        const child = join(path, name);
        if (name !== '.git' || !(await fs.lstat(child)).isDirectory()) {
          await visit(child);
        }
      }
    }
  }
  await visit(dir);
  return result;
}

export async function interruptedTestFixture(f: DevelopmentFixture) {
  const prefix = join(f.dir, 'test-1');
  const cwd = join(f.dir, 'checkout');
  const root = dirname(f.dir);
  let actorPath = '';
  f.args.push('--no-publish');
  f.test = async (_argv, workspace, prompt, _timeout, hostPrefix) => {
    assert(hostPrefix === prefix);
    const input = object(JSON.parse(prompt.split('入力: ')[1]?.split('\n')[0] ?? ''));
    // 旧担当の判断と未採用成果物が新担当へ混入すれば検出できる対照。
    await fs.writeFile(join(workspace, 'unadopted.test.js'), 'throw Error("OLD_ASSET");\n', {
      mode: 0o750,
    });
    const stdout = JSON.stringify({
      targetId: input.targetId,
      status: 'prepared',
      findings: 'OLD_PRIVATE_JUDGMENT',
      files: ['unadopted.test.js'],
    });
    actorPath = await saveActorRecord(f.dir, prefix, 'test', 'interrupted');
    const actor = dirname(actorPath);
    await fs.writeFile(join(actor, 'schema.json'), JSON.stringify(testReplySchema));
    await fs.writeFile(join(actor, 'final.json'), stdout);
    await fs.writeFile(join(actor, 'stderr.log'), '');
    await fs.writeFile(
      join(actor, 'events.jsonl'),
      [
        { type: 'thread.started', thread_id: 'fixture-test' },
        { type: 'item.completed', item: { id: 'item_0', type: 'agent_message', text: stdout } },
        {
          type: 'turn.completed',
          usage: { input_tokens: 10, cached_input_tokens: 0, output_tokens: 5 },
        },
      ]
        .map((event) => JSON.stringify(event))
        .join('\n') + '\n',
    );
    await fs.writeFile(`${prefix}.stdout`, stdout);
    await fs.writeFile(`${prefix}.stderr`, '');
    return { ...ok(stdout), ms: 123 };
  };
  // ホストのexecution保存と終端保存が失敗した実際の経路を使い、保存済み結果の
  // 削除や成功記録の書換えで中断fixtureを偽造しない。
  const write = fs.writeFile;
  const failure = spyOn(fs, 'writeFile').mockImplementation(async (...args) => {
    if (
      typeof args[0] === 'string' &&
      [`${prefix}.execution.json`, join(f.dir, 'result.json.tmp')].includes(args[0])
    ) {
      throw Error('fixture: host storage unavailable');
    }
    return write(...args);
  });
  try {
    await assert.rejects(() => develop(f.args, f.io), /host storage unavailable/);
  } finally {
    failure.mockRestore();
  }
  expect(f.calls.tests).toBe(1);
  expect(f.calls.implementations).toBe(0);
  expect(f.calls.verificationEntries).toBe(0);
  for (const name of ['result.json', 'test-1.execution.json', 'test-1.json', 'test-records.json']) {
    expect(await Bun.file(join(f.dir, name)).exists(), name).toBe(false);
  }
  expect(await fs.readFile(join(cwd, 'result.txt'), 'utf8')).toBe('old');
  assert(actorPath);
  return { prefix, cwd, root, actorPath, dir: join(root, 'test-return') };
}

export type InterruptedTest = Awaited<ReturnType<typeof interruptedTestFixture>>;
export type Observation =
  | 'clear'
  | 'live'
  | 'host'
  | 'host_relative'
  | 'host_omitted'
  | 'host_symlink'
  | 'foreign_host'
  | 'ancestor_host'
  | 'ancestor_return'
  | 'sibling_return'
  | 'unrelated'
  | 'malformed'
  | 'unreadable'
  | 'remote'
  | 'closed_pr'
  | 'github_failed';

function publicationQuery(argv: string[]) {
  return (
    argv[0] === 'gh' && (argv[2]?.endsWith('/pulls') || (argv[1] === 'pr' && argv[2] === 'list'))
  );
}

function processReply(observation: Observation, previousRun: string, argv: string[]) {
  // 新入口の観測契約。旧評価中断のlstart付きfixtureを流用しない。
  expect(argv).toEqual(['ps', '-ww', '-axo', 'pid=,ppid=,command=']);
  const row = (pid: number, parent: number, command: string) => `${pid} ${parent} ${command}\n`;
  if (observation === 'unreadable') {
    return ok('');
  }
  if (observation === 'malformed') {
    return ok('0 0 /sbin/launchd\n');
  }
  const root = dirname(previousRun);
  const cli = 'bun /fixture/scripts/implement/development.ts';
  const host = `${cli} 99 --repo '${join(root, 'repo')}' --no-publish`;
  const returning = `${cli} 99 --repo '${join(previousRun, 'checkout')}' --test-interrupted-run '${previousRun}' --run-dir '${join(root, 'test-return')}' --no-publish`;
  const commands: Partial<Record<Observation, string>> = {
    live: `bun codex-actor.ts test '${previousRun}'`,
    host,
    host_relative: `${cli} 99 --repo '${relative(process.cwd(), join(root, 'repo'))}' --no-publish`,
    host_omitted: `${cli} 99 --no-publish`,
    host_symlink: `${cli} 99 --repo '${join(root, 'repo-alias')}' --no-publish`,
    foreign_host: `${cli} 99 --repo '${join(root, 'foreign')}' --no-publish`,
    ancestor_host: host,
    ancestor_return: returning,
    sibling_return: returning,
    unrelated: 'bun /fixture/other-task.ts',
  };
  const command = commands[observation];
  const ancestor = observation === 'ancestor_host' || observation === 'ancestor_return';
  const active = command ? row(ancestor ? process.ppid : 424242, 1, command) : '';
  return ok(
    row(1, 0, '/sbin/launchd') +
      active +
      (ancestor ? row(process.pid, process.ppid, 'bun test') : ''),
  );
}

function publicationReply(argv: string[], observation: Observation) {
  expect(argv).toContain('state=all');
  const prs = observation === 'closed_pr' ? [{ number: 100, state: 'closed' }] : [];
  return {
    ...ok(JSON.stringify(argv.includes('--slurp') ? [prs] : prs)),
    code: observation === 'github_failed' ? 1 : 0,
  };
}

function observationReply(
  argv: string[],
  observation: Observation,
  previousRun: string,
  observed: string[],
) {
  if (argv[0] === 'ps') {
    observed.push('process');
    return processReply(observation, previousRun, argv);
  }
  if (argv[0] === 'git' && argv.includes('ls-remote') && !argv.includes('--get-url')) {
    observed.push('remote');
    return ok(
      observation === 'remote' ? `${'a'.repeat(40)}\trefs/heads/codex/development-99\n` : '',
    );
  }
  if (publicationQuery(argv)) {
    observed.push('publication');
    return publicationReply(argv, observation);
  }
  return undefined;
}

// 新しい入口の接続名だけ。期待する移行・拒否・保全はIssue本文から定める。
export function returnArgs(f: DevelopmentFixture, t: InterruptedTest) {
  return [
    '99',
    '--repo',
    t.cwd,
    '--test-interrupted-run',
    f.dir,
    '--run-dir',
    t.dir,
    '--no-publish',
  ];
}

export async function withTestReturn(
  f: DevelopmentFixture,
  t: InterruptedTest,
  execute: (io: typeof f.io, observations: string[]) => Promise<void>,
  observation: Observation = 'clear',
) {
  // 別repoは実在する正常なGit repo、symlinkは同じ起動repoを指す。
  if (observation === 'foreign_host') {
    const foreign = join(t.root, 'foreign');
    await fs.mkdir(foreign);
    await initializeTarget(foreign, { ...f.settings, repository: 'team/foreign' });
  }
  if (observation === 'host_symlink') {
    await fs.symlink(f.repo, join(t.root, 'repo-alias'));
  }
  const observed: string[] = [];
  const realCommand = processModule.command;
  const originalIo = f.io.command;
  const script = join(t.root, 'test-return-review.js');
  await fs.writeFile(
    script,
    `import {readFileSync} from 'node:fs';\nconst role='review';\n${reviewReplySource}\nconsole.log(JSON.stringify(reviewReply('accepted','模擬評価')));\n`,
  );
  const command: typeof realCommand = async (...args) => {
    const [argv, , , , prefix] = args;
    const result = observationReply(argv, observation, f.dir, observed);
    if (result) {
      if (prefix) {
        await fs.writeFile(`${prefix}.stdout`, result.stdout);
        await fs.writeFile(`${prefix}.stderr`, result.stderr);
      }
      return result;
    }
    if (argv[0] === 'gh') {
      return originalIo(args[0], args[1], args[2], args[3], args[4]);
    }
    if (argv[1]?.endsWith('/codex-actor.ts') && argv[2] === 'review') {
      return realCommand([process.execPath, script], args[1], args[2], args[3], prefix, args[5]);
    }
    if (argv[0] === 'git' && argv.includes('push')) {
      throw Error('公開は許可されていません');
    }
    return realCommand(...args);
  };
  const hook = spyOn(processModule, 'command').mockImplementation(command);
  try {
    const io = {
      ...f.io,
      command: async (...args: Parameters<typeof command>) => {
        const argv = args[0];
        return argv[0] === 'gh' || argv[0] === 'ps' || argv.includes('ls-remote')
          ? command(...args)
          : originalIo(args[0], args[1], args[2], args[3], args[4]);
      },
      verify: (config: Parameters<typeof run>[0]) => run(config),
    };
    await execute(io, observed);
  } finally {
    hook.mockRestore();
  }
}

export function freshTests(f: DevelopmentFixture, status = 'unnecessary') {
  f.test = async (_argv, cwd, prompt, _timeout, prefix) => {
    assert(prefix);
    expect(await fs.readFile(join(cwd, 'result.txt'), 'utf8')).toBe('old');
    expect(await Bun.file(join(cwd, 'unadopted.test.js')).exists()).toBe(false);
    expect(prompt).not.toContain('OLD_PRIVATE_JUDGMENT');
    const input = object(JSON.parse(await fs.readFile(`${prefix}.target.json`, 'utf8')));
    expect(input.issue).toBe(issue);
    expect(input.stage).toBe('host_return');
    const original = object(
      JSON.parse(await fs.readFile(join(f.dir, 'test-1.target.json'), 'utf8')),
    );
    expect(input.baseCommit).toBe(original.baseCommit);
    expect(input.baseline).toEqual(original.baseline);
    expect(input.files).toEqual(original.files);
    const stdout = JSON.stringify({
      targetId: input.targetId,
      status,
      findings: '新しい独立判断',
      files: [],
    });
    await fs.writeFile(`${prefix}.stdout`, stdout);
    await fs.writeFile(`${prefix}.stderr`, '');
    return ok(stdout);
  };
}
